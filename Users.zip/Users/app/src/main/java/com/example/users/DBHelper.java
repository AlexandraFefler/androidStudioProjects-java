package com.example.users;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "users.db"; //database file/tikiya name. final = const
    public static final int DATABASE_VERSION  = 1; //just has to be here
    public static final String TABLE_NAME = "all_users";
    public static final String NAME = "name";
    public static final String NICK = "nick"; //TODO: change all the 'nickname's to 'nick's to match this
    public static final String PASSWORD = "password";
    public static final String PHONE = "phone";
    public static final String EMAIL = "email";

    public String SQL_Create = "", SQL_Delete = "";

    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) { //creates a database, how many as we want ig
        SQL_Create = "CREATE TABLE "+TABLE_NAME+" (";
        SQL_Create += NAME + " TEXT, ";
        SQL_Create += NICK + " TEXT, ";
        SQL_Create += PASSWORD + " TEXT, ";
        SQL_Create += PHONE + " TEXT, ";
        SQL_Create += EMAIL + " TEXT);";
        sqLiteDatabase.execSQL(SQL_Create);

        //TODO: always add new tables here, SQL_Create2 and so on
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        SQL_Delete = "DROP TABLE IF EXISTS "+TABLE_NAME;
        sqLiteDatabase.execSQL(SQL_Delete);

        //TODO: always add new table deletes here, SQL_Delete2 and so on, but don't write onCreate(sqLiteDatabase) again 


        onCreate(sqLiteDatabase);
    }
}
