package com.example.users;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class Login extends AppCompatActivity {
    ListView lv;

    ArrayAdapter<User> adapter;
    ArrayList<User> all_users;
    User user;
    SQLiteDatabase sqdb;
    DBHelper my_db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        lv = findViewById(R.id.lv);

        all_users = new ArrayList<>();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);

        menu.add(0, 1, 0, "Show all users"); //i1 is the id of the item and it's order in the menu. "back" is last in this case
        menu.add(0, 2, 0, "Update user");
        menu.add(0, 3, 0, "Delete user");

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.back){
            finish();
        }

        if (itemID == 1){
            show();
        }
        if (itemID == 2){
            //update();
        }
        if (itemID == 3){
            //delete();
        }
        return super.onOptionsItemSelected(item);
    }

    private void show() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_NAME, null, null, null, null, null, null); //מבצע חיפוש לפי כל הטבלות, הנאלים האלו מראים לפי מה לחפש
        int col1 = c.getColumnIndex(DBHelper.NAME);
        int col2 = c.getColumnIndex(DBHelper.NICK);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1); //colya (0_0)
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);

            user = new User(s1, s2, s3, s4, s5);
            all_users.add(user);

            c.moveToNext();
        }
        sqdb.close(); //סגירת בגישה לטבלה

        adapter = new ArrayAdapter<User>(this, android.R.layout.simple_list_item_1, all_users);
        lv.setAdapter(adapter);

    }
}