package com.example.users;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Registry extends AppCompatActivity implements View.OnClickListener{
    EditText etName, etNickname, etPassword, etPhone, etEmail;
    Button btnAdd;

    SQLiteDatabase sqdb;
    DBHelper my_db;
    String[] info = new String[5];

    ContentValues cv = new ContentValues();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registry);

        //שלושת פעולות החובה להפעלת הדאטאבייס
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
        //

        etName = findViewById(R.id.etName);
        etNickname = findViewById(R.id.etNickname);
        etPassword = findViewById(R.id.etPassword);
        etPhone = findViewById(R.id.etPhone);
        etEmail = findViewById(R.id.etEmail);
        btnAdd = findViewById(R.id.btnAdd);

        btnAdd.setOnClickListener(this);
    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }



    @Override
    public void onClick(View v) {
        info[0] = etName.getText().toString();
        info[1] = etNickname.getText().toString();
        info[2] = etPassword.getText().toString();
        info[3] = etPhone.getText().toString();
        info[4] = etEmail.getText().toString();

        cv.put(my_db.NAME, info[0]);
        cv.put(my_db.NICK, info[1]);
        cv.put(my_db.PASSWORD, info[2]);
        cv.put(my_db.PHONE, info[3]);
        cv.put(my_db.EMAIL, info[4]);

        sqdb = my_db.getWritableDatabase();
        sqdb.insert(my_db.TABLE_NAME, null, cv);
        sqdb.close();
    }
}