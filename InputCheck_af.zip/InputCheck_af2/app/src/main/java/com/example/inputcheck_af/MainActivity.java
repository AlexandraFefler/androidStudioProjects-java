package com.example.inputcheck_af;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnCheck;
    EditText etName, etID, etTel, etEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnCheck = findViewById(R.id.btn);
        etName = findViewById(R.id.et1);
        etID = findViewById(R.id.et2);
        etTel = findViewById(R.id.et3);
        etEmail = findViewById(R.id.et4);
    }

    public void Check(View view) {
        String errorName = "";
        if(!NameCheck()){
            errorName += "\nname";
            // if name is not valid, turn the field to red
            etName.setHintTextColor(Color.parseColor("#FF5900"));
            etName.setTextColor(Color.parseColor("#FF5900"));
        }
        else{
            // if name is valid, turn field to white
            etName.setHintTextColor(Color.parseColor("#FFFFFF"));
            etName.setTextColor(Color.parseColor("#FFFFFF"));
        }

        if(!IDCheck()){
            errorName += "\nID";
            etID.setHintTextColor(Color.parseColor("#FF5900"));
            etID.setTextColor(Color.parseColor("#FF5900"));
        }
        else{
            etID.setHintTextColor(Color.parseColor("#FFFFFF"));
            etID.setTextColor(Color.parseColor("#FFFFFF"));
        }

        if(!TelCheck()){
            errorName += "\ntel. phone";
            etTel.setHintTextColor(Color.parseColor("#FF5900"));
            etTel.setTextColor(Color.parseColor("#FF5900"));
        }
        else{
            etTel.setHintTextColor(Color.parseColor("#FFFFFF"));
            etTel.setTextColor(Color.parseColor("#FFFFFF"));
        }

        if(!EmailCheck()){
            errorName += "\nEmail";
            etEmail.setHintTextColor(Color.parseColor("#FF5900"));
            etEmail.setTextColor(Color.parseColor("#FF5900"));
        }
        else{
            etEmail.setHintTextColor(Color.parseColor("#FFFFFF"));
            etEmail.setTextColor(Color.parseColor("#FFFFFF"));
        }

        //creating alert dialog in case if there are any errors
        if (errorName != ""){
            AlertDialog.Builder adb;
            adb = new AlertDialog.Builder(this);
            adb.setTitle("Something's wrong");
            adb.setMessage("There's something wrong in the following fields: "+errorName + "\n - - to clear all fields press 'Cancel' - - ");
            adb.setIcon(R.drawable.importanticon);
            adb.setCancelable(false);
            adb.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    etName.setText("");
                    etID.setText("");
                    etTel.setText("");
                    etEmail.setText("");
                }
            });
            AlertDialog adbb = adb.create();
            adbb.show();
        }
        else{
            Toast.makeText(this, "                     Check passed                     ", Toast.LENGTH_LONG).show(); //למה לא לעשות את זה ארוך ;))
        }
    }

    public boolean NameCheck(){
        String name = etName.getText().toString();
        if (!name.isEmpty()){
            char[] charsName = name.toCharArray();
            int count = 0; //counting only letters
            for (char c : charsName){
                if (!Character.isLetter(c) && !Character.isSpaceChar(c)){
                    return false;
                }
                if (Character.isLetter(c)){
                    count++;
                }
            }
            return count > 1;
        }
        return false;
    }

    public boolean IDCheck(){
        String id = etID.getText().toString();
        if (!id.isEmpty()){
            return id.length() == 9;
        }
        return false;
    }

    public boolean TelCheck(){
        String tel = etTel.getText().toString();
        if (!tel.isEmpty()){
            if (tel.startsWith("0")){
                return tel.length() == 9 || tel.length() == 10;
            }
            else{
                if (tel.startsWith("+972")){
                    return tel.length() == 13;
                }
            }
        }
        return false;
    }

    public boolean EmailCheck(){
        String email = etEmail.getText().toString();
        if (!email.isEmpty()){
            if (!email.startsWith("@") && !email.endsWith("@") && CountCharInString(email, '@') == 1 && email.contains(".")){
                //אם ההפרש בין מיקום תו אחד למיקום תו אחר גדול מאחד - סימן שיש ביניהם לפחות תו אחד
                //בנוסף הנקודה חייבת להיות אחרי השטרודל לפי מבנה של דוא"ל
                //לכן אם ההפרש בין מיקום הנקודה למקום השטרודל שלילי - סימן שהנקודה נמצאת רק לפני השטרודל
                return (email.lastIndexOf(".") - email.indexOf("@") > 1 );
            }
        }
        return false;
    }

    public int CountCharInString(String str, char ch){
        int count = 0;
        for (int i = 0; i<str.length(); i++){
            if (ch == (str.charAt(i))){
                count++;
            }
        }
        return count;
    }
}