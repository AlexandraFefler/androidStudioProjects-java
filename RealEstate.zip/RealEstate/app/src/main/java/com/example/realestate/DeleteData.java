package com.example.realestate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class DeleteData extends AppCompatActivity implements View.OnClickListener {
    EditText etDel;
    Button btnDel;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_data);

        etDel = findViewById(R.id.etDel);
        btnDel = findViewById(R.id.btnDel);

        btnDel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                deleteData();
                Toast.makeText(DeleteData.this, "Deleted", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void deleteData() {
        String str = etDel.getText().toString();
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        sqdb.delete(DBHelper.TABLE_NAME, DBHelper.PRICE+"<=?", new String[]{str});
        sqdb.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

    }
}