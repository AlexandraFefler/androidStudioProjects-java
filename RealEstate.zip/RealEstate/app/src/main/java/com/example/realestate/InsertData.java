package com.example.realestate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.Toast;

public class InsertData extends AppCompatActivity implements View.OnClickListener, CompoundButton.OnCheckedChangeListener {
    EditText etProperty, etPrice, etEntryDate, etFloor;
    Switch sw;
    Button btnInsert;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_data);

        etProperty = findViewById(R.id.etProp);
        etPrice = findViewById(R.id.etPrc);
        etEntryDate = findViewById(R.id.etEntryDate);
        etFloor = findViewById(R.id.etFlr);
        sw = findViewById(R.id.swTax);
        btnInsert = findViewById(R.id.btnInsert);

        sw.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked){
                    sw.setText("Taxes included");
                }
                else{
                    sw.setText("No taxes included");
                }
            }
        });

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();

            }
        });
    }

    private void insertData() {
        String strProperty = etProperty.getText().toString();
        String strPrice = etPrice.getText().toString();
        String strEntryDate = etEntryDate.getText().toString();
        String strFloor = etFloor.getText().toString();
        String strTaxes = sw.getText().toString();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(my_db.PROPERTY, strProperty);
        cv.put(my_db.PRICE, Integer.parseInt(strPrice));
        cv.put(my_db.ENTRY, strEntryDate);
        cv.put(my_db.FLOOR, Integer.parseInt(strFloor));
        if (strTaxes.equals("Taxes included")){
            cv.put(my_db.TAXES, "true");
        }
        else{
            cv.put(my_db.TAXES, "false");
        }

        sqdb.insert(my_db.TABLE_NAME, null, cv);
        sqdb.close();

        Toast.makeText(this, "Inserted", Toast.LENGTH_SHORT).show();
        etProperty.setText("");
        etPrice.setText("");
        etEntryDate.setText("");
        etFloor.setText("");
        sw.setChecked(false);
        sw.setText("No taxes included");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

    }
}