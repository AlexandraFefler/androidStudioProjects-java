
package com.example.realestate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class QueryData extends AppCompatActivity implements View.OnClickListener {
    EditText etQ;
    Button btnQ;
    ListView lvQ;

    SQLiteDatabase sqdb;
    DBHelper my_db;
    ReEst rs;
    ArrayList<String> all_data;
    ArrayAdapter<String> adap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_query_data);

        etQ = findViewById(R.id.etQuery);
        btnQ = findViewById(R.id.btnQuery);
        lvQ = findViewById(R.id.lvQuery);
        all_data = new ArrayList<>();

        btnQ.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                search();
            }
        });
    }

    private void search() {
        all_data.clear();
        String str_data = etQ.getText().toString();
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        Cursor c = sqdb.query(DBHelper.TABLE_NAME, null, DBHelper.PROPERTY+"=?", new String[] {str_data}, null, null, null);

        int[] col = new int[5];
        col[0] = c.getColumnIndex(DBHelper.PROPERTY);
        col[1] = c.getColumnIndex(DBHelper.PRICE);
        col[2] = c.getColumnIndex(DBHelper.ENTRY);
        col[3] = c.getColumnIndex(DBHelper.FLOOR);
        col[4] = c.getColumnIndex(DBHelper.TAXES);
        String[] t = new String[5];


        c.moveToFirst();
        while(!c.isAfterLast()){
            for (int i=0; i<col.length; i++){
                t[i] = c.getString(col[i]);
            }

            rs = new ReEst(t[0], Integer.parseInt(t[1]), t[2], Integer.parseInt(t[3]), (t[4].equals("true")));
            all_data.add(rs.toString());
            c.moveToNext();
        }

        adap = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, all_data);
        lvQ.setAdapter(adap);
        sqdb.close();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onClick(View v) {

    }
}