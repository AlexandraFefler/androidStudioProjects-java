package com.example.realestate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class AllView extends AppCompatActivity {
    SQLiteDatabase sqdb;
    DBHelper my_db;
    ListView lv;
    ReEst rs;
    ArrayList<ReEst> all_data;
    ArrayAdapter<ReEst> adap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_view);

        lv = findViewById(R.id.lv);
        all_data = new ArrayList<>();

        my_db = new DBHelper(this);
        show();
        sqdb = my_db.getWritableDatabase();
        sqdb.close();

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    private void show() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_NAME, null, null, null, null, null, null);


        int col1 = c.getColumnIndex(DBHelper.PROPERTY);
        int col2 = c.getColumnIndex(DBHelper.PRICE);
        int col3 = c.getColumnIndex(DBHelper.ENTRY);
        int col4 = c.getColumnIndex(DBHelper.FLOOR);
        int col5 = c.getColumnIndex(DBHelper.TAXES);


        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);


            boolean tax = false;
            if (s5.equals("true")){
                tax = true;
            }

            rs = new ReEst(s1, Integer.valueOf(s2), s3, Integer.valueOf(s4), tax);
            all_data.add(rs);


            c.moveToNext();
        }
        sqdb.close();

        adap = new ArrayAdapter<ReEst>(this, android.R.layout.simple_list_item_1, all_data);
        lv.setAdapter(adap);

    }

}