package com.example.realestate;

public class ReEst {
    public String Property;
    public int Price;
    public String Entry;
    public int Floor;
    public boolean Taxes;

    public ReEst(String property, int price, String entry, int floor, boolean taxes) {
        Property = property;
        Price = price;
        Entry = entry;
        Floor = floor;
        Taxes = taxes; //can only be String "true"/"false"
    }

    public String getProperty() {
        return Property;
    }

    public void setProperty(String property) {
        Property = property;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int price) {
        Price = price;
    }

    public String getEntry() {
        return Entry;
    }

    public void setEntry(String entry) {
        Entry = entry;
    }

    public int getFloor() {
        return Floor;
    }

    public void setFloor(int floor) {
        Floor = floor;
    }

    public boolean isTaxes() {
        return Taxes;
    }

    public void setTaxes(boolean taxes) {
        Taxes = taxes;
    }

    @Override
    public String toString() {
        return "Property: " + Property +
                "\nPrice: " + Price +
                "\nEntry: " + Entry +
                "\nFloor: " + Floor +
                "\nTaxes:" + Taxes;
    }
}
