package com.example.bikurholim_af;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.CalendarView;
import android.widget.CheckBox;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.Calendar;

public class MainActivity extends AppCompatActivity implements View.OnClickListener, CalendarView.OnDateChangeListener {
    TextView tv;
    CalendarView cv;
    CheckBox cheB0, cheB1, cheB2, cheB3, cheB4, cheB5, cheB6, cheB7, cheB8;

    String[] patients = new String[9];
    InputStream is;
    InputStreamReader isr;
    BufferedReader br;

    CheckBox[] cheBs = new CheckBox[9];

    ArrayList<String> all_patients;

    Calendar cld;
    int day, month, year;
    String file_name = "";

    FileOutputStream fos;
    OutputStreamWriter osw;
    BufferedWriter bw;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        menu.add(0,1,0,"Save");
        menu.add(0,2,0,"Report");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID=item.getItemId();
        if (itemID==R.id.back)
            finish();

        if (itemID == 2){
            Intent go = new Intent(this, Report.class);
            startActivity(go);
        }

        if (itemID == 1){
            goSaveVisit();
            for (int i=0; i<cheBs.length; i++){
                cheBs[i].setChecked(false);
            }
        }

        return super.onOptionsItemSelected(item);
    }

    private void goSaveVisit() {
        String allout = "";
        for (int i=0; i<all_patients.size(); i++){
            allout += all_patients.get(i).toString()+"\n";
        }
        try {
            fos = openFileOutput(file_name, Context.MODE_PRIVATE);
            osw = new OutputStreamWriter(fos);
            bw = new BufferedWriter(osw);
            bw.write(allout);
            bw.close();
        } catch (FileNotFoundException e){
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
            //allout = "";
        }
        all_patients.clear();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tv = findViewById(R.id.tv);
        cv = findViewById(R.id.cv);
        CheckBox cheB0 = findViewById(R.id.cheB0);
        CheckBox cheB1 = findViewById(R.id.cheB1);
        CheckBox cheB2 = findViewById(R.id.cheB2);
        CheckBox cheB3 = findViewById(R.id.cheB3);
        CheckBox cheB4 = findViewById(R.id.cheB4);
        CheckBox cheB5 = findViewById(R.id.cheB5);
        CheckBox cheB6 = findViewById(R.id.cheB6);
        CheckBox cheB7 = findViewById(R.id.cheB7);
        CheckBox cheB8 = findViewById(R.id.cheB8);

        goReadFromFile();

        for (int i=0; i<cheBs.length; i++){
            int cheB_id = getResources().getIdentifier("cheB"+i, "id", getPackageName());
            cheBs[i] = findViewById(cheB_id);
            cheBs[i].setText(patients[i]);
            cheBs[i].setOnClickListener(this);
        }

        all_patients = new ArrayList<>();

        cld = Calendar.getInstance();
        day = cld.get(Calendar.DATE);
        month = cld.get(Calendar.MONTH)+1;
        year = cld.get(Calendar.YEAR);
        file_name = "visit_in_"+day+"_"+month+"_"+year;
        tv.setText(file_name);

        cv.setOnDateChangeListener(this);

    }

    private void goReadFromFile() {
        is = this.getResources().openRawResource(R.raw.names);
        isr = new InputStreamReader(is);
        br = new BufferedReader(isr);
        String temp = "";
        int i = 0;
        try {
            while((temp=br.readLine()) != null) {
                patients[i] = temp;
                i++;
            }
            is.close();
        } catch (IOException e){
            e.printStackTrace();
        }
    }

    @Override
    public void onClick(View view) {
        CheckBox temp = (CheckBox) view;
        String t = temp.getText().toString();
        if (temp.isChecked())
            all_patients.add(t);
        else{
            int k = all_patients.indexOf(t);
            all_patients.remove(k);
        }
    }

    @Override
    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
        file_name = "visit_in: "+year+"_"+month+"_"+dayOfMonth;
        tv.setText(file_name);
    }
}