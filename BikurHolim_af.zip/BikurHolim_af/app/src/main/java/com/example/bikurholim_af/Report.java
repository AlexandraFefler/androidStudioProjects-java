package com.example.bikurholim_af;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Report extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    ListView lv;
    Spinner spFiles;

    ArrayList<String> alfiles;
    ArrayList<String> allPatients;
    ArrayAdapter<String> adapFiles, adapPat;

    String filename = "";
    FileInputStream is;
    InputStreamReader isr;
    BufferedReader br;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID=item.getItemId();
        if (itemID==R.id.back)
            finish();

        return super.onOptionsItemSelected(item);
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report);

        spFiles = findViewById(R.id.spFiles);
        lv = findViewById(R.id.lv);

        String[] t = fileList();
        alfiles = new ArrayList<>();
        allPatients = new ArrayList<>();
        allPatients.clear();
        alfiles.add("Choose visit");
        for (int i=0; i<t.length; i++){
            if (!t[i].equals("instant-run")){
                alfiles.add(t[i]);
            }
        }

        adapFiles = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, alfiles); /////////////////////////////
        spFiles.setAdapter(adapFiles);
        spFiles.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener(){
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                goPatients(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                allPatients.clear();
            }
        });
    }

    private void goPatients(int position) {
        allPatients.clear();
        filename = alfiles.get(position);
        is = null;
        try {
            is = openFileInput(filename);
            isr = new InputStreamReader(is);
            br = new BufferedReader(isr);
            String temp = "";
            //allPatients.clear();
            while ((temp=br.readLine()) != null){
                allPatients.add(temp);
            }
            is.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e){
            e.printStackTrace();
        }

        adapPat = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, allPatients); //////////////////////
        lv.setAdapter(adapPat);

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}