package com.example.shopping_alexandrafefler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText etProduct, etPrice, etQuantity;
    Button btnNext, btnFinish;
    ArrayList<Product> arr = new ArrayList<Product>();
    Product prod;
    ////////Adding functions for credits, guide and back options in menu (2 override funs)
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);

        menu.add(0,1,0,"Settings");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID==1) {
            Toast.makeText(this, "Settings menu checked", Toast.LENGTH_SHORT).show();
        }

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        /*if (itemID == R.id.back){
            finish(); //back to previous window
        }*/

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etProduct = findViewById(R.id.etProduct);
        etPrice = findViewById(R.id.etPrice);
        etQuantity = findViewById(R.id.etQuantity);
        btnFinish = findViewById(R.id.btnFinish);
        btnNext = findViewById(R.id.btnNext);

        btnNext.setOnClickListener(this);
        btnFinish.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        if (view==btnFinish) {
            if (arr.size() != 0) { // or arr.isEmpty
                Intent goResult = new Intent(this, Result.class);
                goResult.putExtra("products", arr);
                startActivity(goResult);
            }
            else {
                Toast.makeText(this, "No data to send", Toast.LENGTH_SHORT).show();
            }
        }
        if (view==btnNext) {
            String p = etProduct.getText().toString();
            String pr = etPrice.getText().toString();
            String q = etQuantity.getText().toString();
            Toast.makeText(this, " "+p+", "+pr+", "+q, Toast.LENGTH_SHORT).show();
            if (!p.equals("") && !pr.equals("") && !q.equals("")) {
                prod = new Product (p, Double.parseDouble(pr), Integer.parseInt(q));
                arr.add(prod); //create object array list
                //arr.add(p);
                //arr.add(pr);
                //arr.add(q);
                //arr.add(p);
                //arr.add(pr);
                //arr.add(q);
            }
            else {
                Toast.makeText(this, "One of fields is empty", Toast.LENGTH_SHORT).show();
            }
            etProduct.setText("");
            etPrice.setText("");
            etQuantity.setText("");
            Toast.makeText(this, " "+arr, Toast.LENGTH_SHORT).show();
        }

    }
}