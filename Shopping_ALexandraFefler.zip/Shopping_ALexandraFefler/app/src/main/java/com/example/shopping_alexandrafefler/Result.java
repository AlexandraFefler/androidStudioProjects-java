package com.example.shopping_alexandrafefler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Adapter;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Result extends AppCompatActivity  implements AdapterView.OnItemClickListener, AdapterView.OnItemLongClickListener {
    ArrayList<Product> arrayList;
    ListView lv;
    ListAdapter adapter;
    double totalPay = 0;
    TextView tvTotal;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish(); //back to previous window
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        tvTotal = findViewById(R.id.tvTotal);
        lv = findViewById(R.id.lv);
        lv.setOnItemClickListener(this);
        lv.setOnItemLongClickListener(this);
        Intent take = getIntent();
        arrayList = (ArrayList<Product>) take.getSerializableExtra("products");
        adapter = new ArrayAdapter<Product>(this, android.R.layout.simple_list_item_1, arrayList);
        lv.setAdapter(adapter);
        for (int i = 0; i < arrayList.size(); i++) {
            totalPay += arrayList.get(i).getPrice() * arrayList.get(i).getQuantity();
        }
        tvTotal.setText("Total: " + totalPay);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) { //i = position of clicked line
        double prodPrice = arrayList.get(i).getPrice() * arrayList.get(i).getQuantity();
        Toast.makeText(this, "Total price of "+ arrayList.get(i).getName() + " = "+ prodPrice , Toast.LENGTH_SHORT).show();
        AlertDialog.Builder adb;
        adb = new AlertDialog.Builder((this));
        adb.setTitle("Em, title?");
        adb.setMessage("Total price of "+ arrayList.get(i).getName() + " = "+ prodPrice);
        adb.setIcon(R.drawable.message); //icon from drawable
        adb.setCancelable(false);
        adb.setPositiveButton("אוק", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                lv.setBackgroundColor(Color.BLUE);
            }
        });
        adb.setNegativeButton("noooo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                lv.setBackgroundColor(Color.TRANSPARENT);
            }
        });
        adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        AlertDialog ad = adb.create();
        ad.show();
    }

    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        double prodPrice = arrayList.get(position).getPrice() * arrayList.get(position).getQuantity();
        Toast.makeText(this, "Total price of "+ arrayList.get(position).getName() + " = "+ prodPrice , Toast.LENGTH_SHORT).show();
        AlertDialog.Builder adb;
        adb = new AlertDialog.Builder((this));
        adb.setTitle("Delete Item");
        adb.setMessage("Are you sure");
        adb.setIcon(R.drawable.message); //icon from drawable
        adb.setCancelable(false);
        adb.setPositiveButton("Always", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                arrayList.remove((position));
                adapter = new ArrayAdapter<Product>(Result.this, android.R.layout.simple_list_item_1, arrayList); //instead of only this, we use Result.this to let Android Studio understand which this in all those methods we want to use
                lv.setAdapter(adapter);
            }
        });
        adb.setNegativeButton("noooo", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

            }
        });
        AlertDialog ad = adb.create();
        ad.show(); //??
        return true;
    }
}