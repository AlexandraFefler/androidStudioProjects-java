package com.example.myfruits_alexandrafefler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class ResultSimpleList extends AppCompatActivity {
    ListView lvSimple;
    String[] fruitNames = {"apple", "apricot", "banana", "cherry", "coconut", "grapes", "kiwi", "mango", "melon", "orange", "peach","pear","pineapple","strawberry", "watermelon"};

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        menu.add(0,1,10,"Go to main");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.menuBack){
            finish();
        }
        if (itemID == R.id.menuGuide){
            Intent goCred = new Intent(this, Guide.class);
            startActivity(goCred);
        }
        if (itemID == R.id.menuCredits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }

        if (itemID == 1){
            Intent goCred = new Intent(this, MainActivity.class);
            startActivity(goCred);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_simple_list);
        lvSimple = findViewById(R.id.lv);
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.my_simple_list, R.id.tvItem,fruitNames);
        lvSimple.setAdapter(adapter);
    }
}