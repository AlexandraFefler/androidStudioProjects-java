package com.example.myfruits_alexandrafefler;

public class Fruit {
    private String fruitName;
    private int fruitImageId;
    private int fruitWeight;

    public Fruit(String fruitName, int fruitImageId, int fruitWeight) {
        this.fruitName = fruitName;
        this.fruitImageId = fruitImageId;
        this.fruitWeight = fruitWeight;
    }

    public String getFruitName() {
        return fruitName;
    }

    public void setFruitName(String fruitName) {
        this.fruitName = fruitName;
    }

    public int getFruitImageId() {
        return fruitImageId;
    }

    public void setFruitImageId(int fruitImageId) {
        this.fruitImageId = fruitImageId;
    }

    public int getFruitWeight() {
        return fruitWeight;
    }

    public void setFruitWeight(int fruitWeight) {
        this.fruitWeight = fruitWeight;
    }

    @Override
    public String toString() {
        return "Fruit{" +
                "fruitName='" + fruitName + '\'' +
                ", fruitImageId=" + fruitImageId +
                ", fruitWeight=" + fruitWeight +
                '}';
    }

}
