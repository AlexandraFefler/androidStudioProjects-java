package com.example.myfruits_alexandrafefler;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;

import java.util.ArrayList;

public class ResultCustomList extends AppCompatActivity {
    ListView lvCustom;
    ArrayList <Fruit> list;
    FruitAdapter adapter;
    String[] fruitNames = {"apple", "apricot", "banana", "cherry", "coconut", "grapes", "kiwi", "mango", "melon", "orange", "peach","pear","pineapple","strawberry", "watermelon"};
    int[] imageResourceArray = {R.drawable.apple, R.drawable.apricot, R.drawable.banana, R.drawable.cherry, R.drawable.coconut, R.drawable.grapes, R.drawable.kiwi, R.drawable.mango, R.drawable.melon, R.drawable.orange, R.drawable.peach, R.drawable.pear, R.drawable.pineapple, R.drawable.strawberry, R.drawable.watermelon};

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        menu.add(0,1,10,"Go to main");
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.menuBack){
            finish();
        }
        if (itemID == R.id.menuGuide){
            Intent goCred = new Intent(this, Guide.class);
            startActivity(goCred);
        }
        if (itemID == R.id.menuCredits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }

        if (itemID == 1){
            Intent goCred = new Intent(this, MainActivity.class);
            startActivity(goCred);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result_custom_list);

        lvCustom = findViewById(R.id.lvCustom);
        list = new ArrayList<>();
        for (int i = 0; i<fruitNames.length; i++){
            list.add(new Fruit(fruitNames[i], imageResourceArray[i], (int)((99-10+1)*Math.random())+10));
        }

        adapter = new FruitAdapter(this, R.layout.my_custom_list,this.list); //R.id.tvName, R.id.tvWeight, ??
        lvCustom.setAdapter(adapter);
    }
}