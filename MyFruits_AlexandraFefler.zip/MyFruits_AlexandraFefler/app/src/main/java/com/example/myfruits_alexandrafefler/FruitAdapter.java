package com.example.myfruits_alexandrafefler;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class FruitAdapter extends ArrayAdapter {
    private Context context;
    private ArrayList<Fruit> list;
    private int layout;
    int[] imageResourceArray = {R.drawable.apple, R.drawable.apricot, R.drawable.banana, R.drawable.cherry, R.drawable.coconut, R.drawable.grapes, R.drawable.kiwi, R.drawable.mango, R.drawable.melon, R.drawable.orange, R.drawable.peach, R.drawable.pear, R.drawable.pineapple, R.drawable.strawberry, R.drawable.watermelon};


    public FruitAdapter(@NonNull Context context, int layout, @NonNull ArrayList<Fruit> list) {
        super(context, layout, list);

        this.context=context;
        this.layout=layout;
        this.list=list;
    }

    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        LayoutInflater layoutInflater = ((AppCompatActivity)context).getLayoutInflater();

        View view = layoutInflater.inflate(layout,parent,false);

        Fruit fruit = this.list.get(position);

        TextView tvName = view.findViewById(R.id.tvName);
        TextView tvWeight = view.findViewById(R.id.tvWeight);
        ImageView ivCustom = view.findViewById(R.id.ivCustom);

        tvName.setText(fruit.getFruitName());
        tvWeight.setText(String.valueOf(fruit.getFruitWeight())+" gramm");
        ivCustom.setImageResource(fruit.getFruitImageId());

        return view;
    }
}
