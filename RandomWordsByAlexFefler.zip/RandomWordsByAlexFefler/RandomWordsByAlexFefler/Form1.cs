﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomWordsByAlexFefler
{
    public partial class Form1 : Form
    {
        string[] words = new string[50];
        int current = 0;


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            words[current] = textBox1.Text;
            current++;
            label4.Text = "c = " + current;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Random rnd = new Random();
            label1.Text = words[rnd.Next(0, current)];
            label2.Text = words[rnd.Next(0, current)];
            label3.Text = words[rnd.Next(0, current)];
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
