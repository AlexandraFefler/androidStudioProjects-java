package com.fraiman.amit.notification_and_service;

import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NotificationCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class Start extends AppCompatActivity {

    Button btn01, btn02, btn03, btn04;
    int year,month,date,hour,minute,second;
    private Calendar c;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        btn01=findViewById(R.id.btn01);
        btn02=findViewById(R.id.btn02);
        btn03=findViewById(R.id.btn03);
        btn04=findViewById(R.id.btn04);

        btn01.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String notiTitle="This is a notification for you";
                String notiText="Press here without do something";

                Intent intent=new Intent();

                makeNotification(intent, notiTitle, notiText);

            }
        });

        //==============================================

        btn02.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String notiTitle="Important notification for you";
                String notiText="Press here for open DoSomething activity";

                Intent intent=new Intent(Start.this, DoSomething.class);

                makeNotification(intent, notiTitle, notiText);

            }
        });

        //==============================================

        btn03.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent after = new Intent(Start.this, AfterService.class);

                PendingIntent afterIntent = PendingIntent.getService(Start.this,
                        0, after, 0);


                AlarmManager alma = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

                Calendar c = Calendar.getInstance();
                c.setTimeInMillis(System.currentTimeMillis());
                c.add(Calendar.SECOND, 60);

                alma.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), afterIntent);

            }
        });

        //==============================================

        btn04.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                c = Calendar.getInstance();
                year=2018;
                month=4; //May
                date=13;
                hour=8;
                minute=2;
                second=0;

                takeMonthDay();

            }
        });

        //==============================================
    }

    private void TakeHourMinute() {
        AlertDialog.Builder adb=new AlertDialog.Builder(this);
        adb.setTitle("Choose month and day");
        TimePicker tp=new TimePicker(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            tp.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
                @Override
                public void onTimeChanged(TimePicker timePicker, int i, int i1) {
                    hour=i;
                    minute=i1;
                }
            });
        }
        adb.setView(tp);
        adb.setPositiveButton("Start service",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        Intent after = new Intent(Start.this, AfterService.class);

                        PendingIntent afterIntent = PendingIntent.getService(Start.this,
                                0, after, 0);


                        AlarmManager alma = (AlarmManager) getSystemService(Context.ALARM_SERVICE);

                        c.set(year, month,date,hour,minute, second);

                        alma.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), afterIntent);
                    }
                });
        adb.create().show();

    }

    private void takeMonthDay() {
        AlertDialog.Builder adb=new AlertDialog.Builder(this);
        adb.setTitle("Choose month and day");
        DatePicker dp=new DatePicker(this);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            dp.setOnDateChangedListener(new DatePicker.OnDateChangedListener() {
                @Override
                public void onDateChanged(DatePicker datePicker, int i, int i1, int i2) {
                    year=i;
                    month=i1+1;
                    date=i2;
                }
            });
        }
        adb.setView(dp);
        adb.setPositiveButton("ok",
                new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        TakeHourMinute();
                    }
                });
        adb.create().show();

    }

    public void makeNotification(Intent intent, String notiTitle, String notiText)  {

        PendingIntent contentIntent=PendingIntent.getActivity(Start.this,
                0, intent,PendingIntent.FLAG_CANCEL_CURRENT);

        //

        NotificationCompat.Builder builder=new NotificationCompat.Builder(Start.this);

        //

        builder.setContentIntent(contentIntent);
        builder.setSmallIcon(R.drawable.small_wolf);
        builder.setContentTitle(notiTitle);
        builder.setContentText(notiText);
        builder.setDefaults(Notification.DEFAULT_SOUND);
        builder.setWhen(System.currentTimeMillis());

        builder.setLargeIcon(BitmapFactory.decodeResource(getResources(),R.drawable.wolf));

        builder.setDefaults(Notification.DEFAULT_LIGHTS);

        //builder.setSound(Uri.parse("R.raw.gudok"));

        Notification noti=builder.build();

        NotificationManager notificationManager=
                (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationManager.notify(1, noti);
    }
}
