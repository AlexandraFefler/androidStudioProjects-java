matrix = []
row_input = int(input("Enter row: "))
col_input = int(input("Enter col: "))
num = int(input("Enter num: "))

#filling the matrix:
for row in range(row_input):
    row_add = []
    for col in range(col_input):
        row_add.append(num)
    matrix.append(row_add)
#changing the matrix according to targil:
for row in range(len(matrix)):
    for col in range(len(matrix[row])):
        if row%2==1 and col%2==1:
            matrix[row][col] += 1
        elif row%2==0 and col%2==0:
            matrix[row][col] += 1
#printing the matrix:
for i in matrix:
    print(i)