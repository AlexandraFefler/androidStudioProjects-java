package com.example.medicines;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.RadialGradient;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    RadioGroup rgMed, rgFund, rgPay;
    RadioButton rb1, rb2, rb3, rb4, rb5, rb6, rb7, rb8, rb9, rb10, rb11, rb12, rb13;
    Button btnAdd, btnRes;
    

    //creating a menu with "credits", "guide" an "back"
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.menuBack){
            finish();
        }
        if (itemID == R.id.menuGuide){
            Intent goCred = new Intent(this, Guide.class);
            startActivity(goCred);
        }
        if (itemID == R.id.menuCredits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rgMed = findViewById(R.id.rgMed);
        rgFund = findViewById(R.id.rgFund);
        rgPay = findViewById(R.id.rgPay);
        rb1 = findViewById(R.id.rb1);
        rb2 = findViewById(R.id.rb2);
        rb3 = findViewById(R.id.rb3);
        rb4 = findViewById(R.id.rb4);
        rb5 = findViewById(R.id.rb5);
        rb6 = findViewById(R.id.rb6);
        rb7 = findViewById(R.id.rb7);
        rb8 = findViewById(R.id.rb8);
        rb9 = findViewById(R.id.rb9);
        rb10 = findViewById(R.id.rb10);
        rb11 = findViewById(R.id.rb11);
        rb12 = findViewById(R.id.rb12);
        rb13 = findViewById(R.id.rb13);
        btnAdd = findViewById(R.id.btnAdd);
        btnRes = findViewById(R.id.btnGo);

        btnAdd.setOnClickListener(this);
        btnRes.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        if (view == btnAdd){

        }
        if (view == btnRes){
            Intent goResult = new Intent(this, ResultActivity.class);
            startActivity(goResult);
        }

    }
}