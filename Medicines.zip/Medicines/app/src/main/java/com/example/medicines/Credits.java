package com.example.medicines;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

public class Credits extends AppCompatActivity {

    //creating a menu with "credits", "guide" an "back"
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();
        if (itemID == R.id.menuBack){
            finish();
        }
        if (itemID == R.id.menuGuide){
            Intent goCred = new Intent(this, Guide.class);
            startActivity(goCred);
        }
        if (itemID == R.id.menuCredits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credits);
    }
}