package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class TeacherProfile extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows teacher profile information
     */
    TextView tvHelloName, tvID, tvAddress, tvExp, tvTeachingSubjects, tvPrice, tvExtraNotes, tvPhone, tvEmail;
    ImageView ivPfp;
    String teacherID = "";
    String teacherPass = "";

    SQLiteDatabase sqdb;
    DBHelper my_db;
    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_profile);

        tvHelloName = findViewById(R.id.tvHelloName);
        tvID = findViewById(R.id.tvID);
        tvAddress = findViewById(R.id.tvAddressTch);
        tvExp = findViewById(R.id.tvExp);
        tvTeachingSubjects = findViewById(R.id.tvTeachingSubjects);
        tvPrice = findViewById(R.id.tvPrice);
        tvExtraNotes = findViewById(R.id.tvExtraNotes);
        tvPhone = findViewById(R.id.tvPhone);
        tvEmail = findViewById(R.id.tvEmail);
        ivPfp = findViewById(R.id.PersonalTeacherPfp);

        Intent take = getIntent();
        teacherID = take.getStringExtra("teacherID");
        teacherPass = take.getStringExtra("teacherPass");

        my_db = new DBHelper(this);
        showUserData();
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        menu.add(0, 2, 0, "Change user info");
        menu.add(0, 3, 0, "Teacher settings");
        menu.add(0, 4, 0, "Notifications panel");
        menu.add(0, 5, 0, "My schedule");
        return true;
    }
    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == 1) {
            Intent goUsersList = new Intent(this, UsersList.class);
            startActivity(goUsersList);
        }
        if (itemID == 2) {
            Intent goSettings = new Intent(this, Registration.class);
            goSettings.putExtra("isTeacher", true);
            goSettings.putExtra("ID", teacherID);
            goSettings.putExtra("Pass", teacherPass);
            startActivity(goSettings);
        }

        if (itemID == 3){
            Intent goTeacherSettings = new Intent(this, TeacherSettings.class);
            goTeacherSettings.putExtra("teacherID", teacherID);
            goTeacherSettings.putExtra("teacherPass", teacherPass);
            startActivity(goTeacherSettings);
        }

        if (itemID == 4){
            Intent goNotifsPanel = new Intent(this, NotificationsPanel.class);
            goNotifsPanel.putExtra("ID", teacherID);
            goNotifsPanel.putExtra("Pass", teacherPass);
            startActivity(goNotifsPanel);
        }
        if (itemID == 5){
            Intent goSch = new Intent(this, SchedulePanel.class);
            goSch.putExtra("ID", teacherID);
            goSch.putExtra("Pass", teacherPass);
            startActivity(goSch);
        }

        if (itemID == R.id.credits) {
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide) {
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back) {
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * counts how many times a char appears in a string
     * @param str
     * @param ch
     * @return
     */
    public int countCharInString(String str, char ch) {
        int count = 0;
        for (int i = 0; i < str.length(); i++) {
            if (ch == (str.charAt(i))) {
                count++;
            }
        }
        return count;
    }
    /**
     * Shows users data
     */
    private void showUserData() {
        Teacher teacher = null;
        boolean flag = false;

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);

        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s3 = c.getString(col3);
            String s10 = c.getString(col10);
            if (teacherID.equals(s1) && teacherPass.equals(s3)) {
                flag = true;
                boolean isTeacher = false;
                if (c.getString(col8).equals("true")) {
                    isTeacher = true;
                }
                int priceInt = 0;
                if (!s10.isEmpty()) {
                    priceInt = Integer.parseInt(c.getString(col10));
                }
                teacher = new Teacher(s1, c.getString(col2), s3, c.getString(col4), c.getString(col5), c.getString(col6), c.getString(col7), isTeacher, c.getString(col9), priceInt, c.getString(col11), c.getString(col12));

                tvHelloName.setText(tvHelloName.getText() + teacher.getName());
                tvID.setText(tvID.getText() + teacher.getID());
                tvExp.setText(tvExp.getText() + "\n" + teacher.getExperience());

                //breaking the teachingSubjects parameter into an array of strings
                int lngth = countCharInString(teacher.getTeachingsubjects(), '@');
                String[] teachingSubjsArr = new String[lngth + 1]; //same here
                teachingSubjsArr = teacher.getTeachingsubjects().split("@");
                //breaking each subject to 2 parts - subject name and subject level
                String[] subject = new String[2];
                String str = "";
                if (!teacher.getTeachingsubjects().isEmpty()){
                    for (int i = 0; i < teachingSubjsArr.length; i++) {
                        subject = teachingSubjsArr[i].split("_");
                        str += "\n" + subject[0] + ", level: " + subject[1];
                    }
                }
                tvTeachingSubjects.setText(tvTeachingSubjects.getText() + str);
                String priceString = "";
                if (teacher.getPrice() != 0) {
                    priceString = String.valueOf(teacher.getPrice());
                }
                tvPrice.setText(tvPrice.getText() + " " + priceString);
                tvExtraNotes.setText(tvExtraNotes.getText() + teacher.getExtraComments());

                //if there is phone number or email, show their text view. else, keep them invisible
                if (!teacher.getPhone().isEmpty()) {
                    tvPhone.setText(tvPhone.getText() + teacher.getPhone());
                    tvPhone.setVisibility(View.VISIBLE);
                } else {
                    tvPhone.setVisibility(View.INVISIBLE);
                }

                if (!teacher.getEmail().isEmpty()) {
                    tvEmail.setText(tvEmail.getText() + teacher.getEmail());
                    tvEmail.setVisibility(View.VISIBLE);
                } else {
                    tvEmail.setVisibility(View.INVISIBLE);
                }

                if (!teacher.getAddress().isEmpty()) {
                    tvAddress.setText(tvAddress.getText() + teacher.getAddress());
                } else {
                    tvAddress.setText(tvAddress.getText() + "not specified");
                }

                if(!teacher.getPic().isEmpty()){
                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.parse(teacher.getPic()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ivPfp.setImageBitmap(bitmap);
                }
                else{
                    int imgRes = getResources().getIdentifier("@drawable/defaultprofilepic", null, getPackageName());
                    ivPfp.setImageDrawable(getResources().getDrawable(imgRes));
                }
            }
            c.moveToNext();
        }
        sqdb.close();
    }
}