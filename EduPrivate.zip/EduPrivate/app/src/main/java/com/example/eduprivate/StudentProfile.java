package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

public class StudentProfile extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows student profile information
     */
    TextView tvHelloName, tvID, tvAddress, tvPhone, tvEmail, tvExtraNotes;
    Button btnSearch;
    String studentID = "";
    String studentPass = "";
    ImageView ivPfp;

    SQLiteDatabase sqdb;
    DBHelper my_db;
    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_profile);

        tvHelloName = findViewById(R.id.tvHelloNamest);
        tvID = findViewById(R.id.tvIDst);
        tvAddress = findViewById(R.id.tvAddressSt);
        tvPhone = findViewById(R.id.tvPhonest);
        tvEmail = findViewById(R.id.tvEmailst);
        btnSearch = findViewById(R.id.btnSearch);
        tvExtraNotes = findViewById(R.id.tvExtraNotes);
        ivPfp = findViewById(R.id.ivPfpSt);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goSearch = new Intent(StudentProfile.this, SearchTeachers.class);
                goSearch.putExtra("studentID", studentID);
                goSearch.putExtra("studentPass", studentPass);
                startActivity(goSearch);
            }
        });

        Intent take = getIntent();
        studentID = take.getStringExtra("studentID");
        studentPass = take.getStringExtra("studentPass");
        my_db = new DBHelper(this);
        showUserData();
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }

    /**
     * Shows users data
     */
    private void showUserData() {
        User user = null;
        boolean flag=false;

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s3 = c.getString(col3);
            if (studentID.equals(s1) && studentPass.equals(s3)) {
                flag = true;
                user = new User(s1, c.getString(col2), s3, c.getString(col4), c.getString(col5), c.getString(col6), c.getString(col7), false, c.getString(col9));
                tvHelloName.setText(tvHelloName.getText() + user.getName());
                tvID.setText(tvID.getText() + user.getID());

                tvExtraNotes.setText(tvExtraNotes.getText() + user.getExtraComments());

                //if there is phone number or email, show their text view. else, keep them invisible
                if (!user.getPhone().isEmpty()) {
                    tvPhone.setText(tvPhone.getText() + user.getPhone());
                } else {
                    tvPhone.setText(tvPhone.getText() + "not specified");
                }

                if (!user.getEmail().isEmpty()) {
                    tvEmail.setText(tvEmail.getText() + user.getEmail());
                } else {
                    tvEmail.setText(tvEmail.getText() + "not specified");
                }

                if (!user.getAddress().isEmpty()) {
                    tvAddress.setText(tvAddress.getText() + user.getAddress());
                } else {
                    tvAddress.setText(tvAddress.getText() + "not specified");
                }

                if(!user.getPic().isEmpty()){
                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.parse(user.getPic()));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ivPfp.setImageBitmap(bitmap);
                }
                else{
                    int imgRes = getResources().getIdentifier("@drawable/defaultprofilepic", null, getPackageName());
                    ivPfp.setImageDrawable(getResources().getDrawable(imgRes));
                }
            }
            c.moveToNext();
        }
        sqdb.close();
    }

    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        menu.add(0, 2, 0, "Change user info");
        menu.add(0, 3, 0, "Notifications panel");
        menu.add(0, 4, 0, "My schedule");
        return true;
    }
    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == 2) {
            Intent goSettings = new Intent(this, Registration.class);
            goSettings.putExtra("isTeacher", false);
            goSettings.putExtra("ID", studentID);
            goSettings.putExtra("Pass", studentPass);
            startActivity(goSettings);
        }

        if (itemID == 3){
            Intent goNotifsPanel = new Intent(this, NotificationsPanel.class);
            goNotifsPanel.putExtra("ID", studentID);
            goNotifsPanel.putExtra("Pass", studentPass);
            startActivity(goNotifsPanel);
        }
        if (itemID == 4){
            Intent goSch = new Intent(this, SchedulePanel.class);
            goSch.putExtra("ID", studentID);
            goSch.putExtra("Pass", studentPass);
            startActivity(goSch);
        }

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
}