package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Guide extends AppCompatActivity {

    /**
     * @author Alexandra Fefler
     * This activity shows guide for user
     */

    TextView tv;
    InputStream is;
    InputStreamReader isr;
    BufferedReader br;

    /**
     * Creates starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to star UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        tv = findViewById(R.id.textView10);

        is = null;
        is = getResources().openRawResource(R.raw.guide);
        isr = new InputStreamReader(is);
        br = new BufferedReader(isr);
        String temp = "", all = "";
            try {
                while (((temp=br.readLine()) != null))
                    all += "\n"+temp;
                tv.setText(all);
                is.close();
            } catch (IOException e) {
                e.printStackTrace();
            }

    }
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }
    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();


        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

}