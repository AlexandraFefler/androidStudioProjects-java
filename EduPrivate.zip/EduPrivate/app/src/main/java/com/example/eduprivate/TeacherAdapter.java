package com.example.eduprivate;

import android.content.Context;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;

public class TeacherAdapter extends ArrayAdapter {
    /**
     * @author Alexandra Fefler
     * This class adapts an ArrayList of Teachers into a List View
     */
    private Context context;
    private ArrayList<Teacher> list;
    private int layout;

    /**
     * Creates TeacherAdapter object
     * @param context
     * @param layout
     * @param list
     */
    public TeacherAdapter(@NonNull Context context, int layout, @NonNull ArrayList<Teacher> list) {
        super(context, layout, list);

        this.context=context;
        this.layout=layout;
        this.list=list;
    }

    /**
     * Adapts an ArrayList of Notifications into a List View
     * @param position
     * @param convertView
     * @param parent
     * @return
     */
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        LayoutInflater layoutInflater = ((AppCompatActivity)context).getLayoutInflater();

        View view = layoutInflater.inflate(layout,parent,false);

        Teacher teacher = this.list.get(position);

        TextView tvTeacherName = view.findViewById(R.id.tvTeacherName);
        TextView tvTeacherPrice = view.findViewById(R.id.tvTeacherPrice);
        TextView tvContactInfo = view.findViewById(R.id.tvContactInfoTeacher);
        ImageView ivTeacherPfp = view.findViewById(R.id.ivTeacherPfp);

        tvTeacherName.setText(teacher.getName());
        tvTeacherPrice.setText(String.valueOf(teacher.getPrice())+" ILS per hour");
        String tel = teacher.getPhone();
        if (teacher.getPhone().isEmpty()){
            tel = " - ";
        }
        String email = teacher.getEmail();
        if (teacher.getEmail().isEmpty()){
            email = " - ";
        }
        tvContactInfo.setText("Tel.: "+tel+"\nEmail: "+email);

        if(!teacher.getPic().isEmpty()){
            Bitmap bitmap = null;
            try {
                bitmap = MediaStore.Images.Media.getBitmap(context.getContentResolver(), Uri.parse(teacher.getPic()));
            } catch (IOException e) {
                e.printStackTrace();
            }
            ivTeacherPfp.setImageBitmap(bitmap);
        }
        else{
            int imgRes = context.getResources().getIdentifier("@drawable/defaultprofilepic", null, context.getPackageName());
            ivTeacherPfp.setImageDrawable(context.getResources().getDrawable(imgRes));
        }
        return view;
    }
}
