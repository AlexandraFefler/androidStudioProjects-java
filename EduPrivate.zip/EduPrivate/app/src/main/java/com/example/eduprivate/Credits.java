package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Credits extends AppCompatActivity implements View.OnClickListener {
    /**
     * @author Alexandra Fefler
     * This activity shows credits for the project
     */
    TextView tv;
    InputStream is;
    InputStreamReader isr;
    BufferedReader br;

    Button btnSms, btnEmail;

    //for sms
    String phoneNum="0522236749", smsMsg="Hi I use your app";
    final int SEND_SMS_PERMISSION_REQUEST_CODE=1;

    //for email
    String adr="sasha.fefler@gmail.com", sub="I'm an EduPrivate user", text="Hello, I'm using your app";

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credits);

        tv = findViewById(R.id.textView9);

        is = null;
        is = getResources().openRawResource(R.raw.credits);
        isr = new InputStreamReader(is);
        br = new BufferedReader(isr);
        String temp = "", all = "";
        try {
            while (((temp=br.readLine()) != null))
                all += "\n"+temp;
            tv.setText(all);
            is.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        if(checkPermission(Manifest.permission.SEND_SMS))
        {
            Toast.makeText(this, "Permission given", Toast.LENGTH_LONG).show();
        }
        else
        {
            Toast.makeText(this, "No permission given, requesting now", Toast.LENGTH_LONG).show();
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.SEND_SMS}, SEND_SMS_PERMISSION_REQUEST_CODE );
        }

        btnSms = findViewById(R.id.btnSms);
        btnEmail = findViewById(R.id.btnEmail);

        btnSms.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkPermission(Manifest.permission.SEND_SMS))
                {
                    SmsManager smsManager=SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNum, null,smsMsg,null,null);
                    Toast.makeText(Credits.this, "Message sent!!!", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(Credits.this, "Permission denied!", Toast.LENGTH_SHORT).show();
            }
        });
        btnEmail.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goMail=new Intent(Intent.ACTION_SEND);
                goMail.putExtra(Intent.EXTRA_EMAIL, new String[] {adr});
                goMail.putExtra(Intent.EXTRA_SUBJECT, sub);
                goMail.putExtra(Intent.EXTRA_TEXT, text);
                goMail.setType("*/*");
                startActivity(goMail);
            }
        });
    }

    /**
     *Checks if sms permission is granted
     * @param sendSms
     * @return if permission is granted
     */
    private boolean checkPermission(String sendSms) {
        int check = ContextCompat.checkSelfPermission(this,sendSms);
        return check == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish(); //back to previous window
        }

        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onClick(View v) {

    }
}