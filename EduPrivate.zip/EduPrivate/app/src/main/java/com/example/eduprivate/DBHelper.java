package com.example.eduprivate;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class DBHelper extends SQLiteOpenHelper {
    /**
     * @author Alexandra Fefler
     * This class helps creates the database
     */
    public static final String DATABASE_NAME = "eduprivate.db";
    public static final int DATABASE_VERSION  = 1;

    public static final String ID = "id"; //used in both tables

    //used in all users table
    public static final String TABLE_ALL_USERS = "all_users";
    public static final String NAME = "name";
    public static final String PASSWORD = "password";
    public static final String PHONE = "phone";
    public static final String EMAIL = "email";
    public static final String ADDRESS = "address";
    public static final String PIC = "pic";
    public static final String ISTEACHER = "isteacher";
    public static final String EXTRACOMMENTS = "extracomments";

    //used in teachers table
    public static final String TABLE_TEACHERS = "all_teachers";
    public static final String PRICE = "price";
    public static final String EXPERIENCE = "experience";
    public static final String TEACHINGSUBJECTS = "teachingsubjects";

    public static final String TABLE_NOTIFICATIONS = "all_notifications";
    public static final String IDRECEIVER = "idreceiver";
    public static final String PASSRECEIVER = "passreceiver";
    public static final String NOTIFICATIONTEXT = "notificationtext";
    public static final String LESSONDAY = "lessonday";
    public static final String LESSONHOUR = "lessonhour";
    public static final String LESSONSUBJECT = "lessonsubject";
    public static final String OTHERID = "otherid";
    public static final String OTHERPASS = "otherpass";
    public static final String NOTIFICATIONTYPE = "notificationtype";
    public static final String ISACTIVE = "isactive";

    public static final String TABLE_SCHEDULES = "all_schedules";
    public static final String IDOWNER = "idowner";
    public static final String PASSOWNER = "passowner";
    public static final String SUNDAY = "sunday";
    public static final String MONDAY = "monday";
    public static final String TUESDAY = "tuesday";
    public static final String WEDNESDAY = "wednesday";
    public static final String THURSDAY = "thursday";
    public static final String FRIDAY = "friday";
    public static final String SATURDAY = "saturday";


    public String SQL_Create1 = "", SQL_Delete1 = "";
    public String SQL_Create2 = "", SQL_Delete2 = "";
    public String SQL_Create3 = "", SQL_Delete3 = "";
    public String SQL_Create4 = "", SQL_Delete4 = "";

    /**
     * Creates DBHelper object
     * @param context
     */
    public DBHelper(@Nullable Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }


    /**
     * Creates the database
     * @param db
     */
    @Override
    public void onCreate(SQLiteDatabase db) {
        SQL_Create1 = "CREATE TABLE "+TABLE_ALL_USERS+" (";
        SQL_Create1 += ID + " TEXT, ";
        SQL_Create1 += NAME + " TEXT, ";
        SQL_Create1 += PASSWORD + " TEXT, ";
        SQL_Create1 += PHONE + " TEXT, ";
        SQL_Create1 += EMAIL + " TEXT, ";
        SQL_Create1 += ADDRESS + " TEXT, ";
        SQL_Create1 += PIC + " TEXT, ";
        SQL_Create1 += ISTEACHER + " TEXT, ";
        SQL_Create1 += EXTRACOMMENTS + " TEXT);";
        db.execSQL(SQL_Create1);

        SQL_Create2 = "CREATE TABLE "+TABLE_TEACHERS+" (";
        SQL_Create2 += ID + " TEXT, ";

        SQL_Create2 += NAME + " TEXT, ";
        SQL_Create2 += PASSWORD + " TEXT, ";
        SQL_Create2 += PHONE + " TEXT, ";
        SQL_Create2 += EMAIL + " TEXT, ";
        SQL_Create2 += ADDRESS + " TEXT, ";
        SQL_Create2 += PIC + " TEXT, ";
        SQL_Create2 += ISTEACHER + " TEXT, ";
        SQL_Create2 += EXTRACOMMENTS + " TEXT, ";

        SQL_Create2 += PRICE + " TEXT, ";
        SQL_Create2 += EXPERIENCE + " TEXT, ";
        SQL_Create2 += TEACHINGSUBJECTS + " TEXT);";
        db.execSQL(SQL_Create2);

        SQL_Create3 = "CREATE TABLE "+TABLE_NOTIFICATIONS+" (";
        SQL_Create3 += IDRECEIVER + " TEXT, ";
        SQL_Create3 += PASSRECEIVER + " TEXT, ";
        SQL_Create3 += NOTIFICATIONTEXT + " TEXT, ";
        SQL_Create3 += LESSONDAY + " TEXT, ";
        SQL_Create3 += LESSONHOUR + " TEXT, ";
        SQL_Create3 += LESSONSUBJECT + " TEXT, ";
        SQL_Create3 += OTHERID + " TEXT, ";
        SQL_Create3 += OTHERPASS + " TEXT, ";
        SQL_Create3 += NOTIFICATIONTYPE + " TEXT, ";
        SQL_Create3 += ISACTIVE + " TEXT);";
        db.execSQL(SQL_Create3);

        SQL_Create4 = "CREATE TABLE "+TABLE_SCHEDULES+" (";
        SQL_Create4 += IDOWNER + " TEXT, ";
        SQL_Create4 += PASSOWNER + " TEXT, ";
        SQL_Create4 += SUNDAY + " TEXT, ";
        SQL_Create4 += MONDAY + " TEXT, ";
        SQL_Create4 += TUESDAY + " TEXT, ";
        SQL_Create4 += WEDNESDAY + " TEXT, ";
        SQL_Create4 += THURSDAY + " TEXT, ";
        SQL_Create4 += FRIDAY + " TEXT, ";
        SQL_Create4 += SATURDAY + " TEXT);";
        db.execSQL(SQL_Create4);
    }

    /**
     * Upgrades database
     * @param db
     * @param oldVersion
     * @param newVersion
     */
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        SQL_Delete1 = "DROP TABLE IF EXISTS "+TABLE_ALL_USERS;
        db.execSQL(SQL_Delete1);

        SQL_Delete2= "DROP TABLE IF EXISTS "+TABLE_TEACHERS;
        db.execSQL(SQL_Delete2);

        SQL_Delete3= "DROP TABLE IF EXISTS "+TABLE_NOTIFICATIONS;
        db.execSQL(SQL_Delete3);

        SQL_Delete4= "DROP TABLE IF EXISTS "+TABLE_SCHEDULES;
        db.execSQL(SQL_Delete4);

        onCreate(db);
    }
}