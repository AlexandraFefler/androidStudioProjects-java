package com.example.eduprivate;

public class Schedule {
    /**
     * @author Alexandra Fefler
     * This class represents a schedule and it's properties
     */
    private String idOwner;
    private String passOwner;
    private String sunday;
    private String monday;
    private String tuesday;
    private String wednesday;
    private String thursday;
    private String friday;
    private String saturday;

    /**
     *  Creates a Schedule object
     * @param idOwner
     * @param passOwner
     * @param sunday
     * @param monday
     * @param tuesday
     * @param wednesday
     * @param thursday
     * @param friday
     * @param saturday
     */
    public Schedule(String idOwner, String passOwner, String sunday, String monday, String tuesday, String wednesday, String thursday, String friday, String saturday) {
        this.idOwner = idOwner;
        this.passOwner = passOwner;
        this.sunday = sunday;
        this.monday = monday;
        this.tuesday = tuesday;
        this.wednesday = wednesday;
        this.thursday = thursday;
        this.friday = friday;
        this.saturday = saturday;
    }

    /**
     * Getter for id of owner
     * @return
     */
    public String getIdOwner() {
        return idOwner;
    }

    /**
     * Setter for id of owner
     * @param idOwner
     */
    public void setIdOwner(String idOwner) {
        this.idOwner = idOwner;
    }

    /**
     * Getter for password of owner
     * @return
     */
    public String getPassOwner() {
        return passOwner;
    }

    /**
     * Setter for password of owner
     * @param passOwner
     */
    public void setPassOwner(String passOwner) {
        this.passOwner = passOwner;
    }

    /**
     * Getter for sunday lessons
     * @return
     */
    public String getSunday() {
        return sunday;
    }

    /**
     * Setter for sunday lessons
     * @param sunday
     */
    public void setSunday(String sunday) {
        this.sunday = sunday;
    }

    /**
     * Getter for monday lessons
     * @return
     */
    public String getMonday() {
        return monday;
    }

    /**
     * Setter for monday lessons
     * @param monday
     */
    public void setMonday(String monday) {
        this.monday = monday;
    }

    /**
     * Getter for tuesday lessons
     * @return
     */
    public String getTuesday() {
        return tuesday;
    }

    /**
     * Setter for tuesday lessons
     * @param tuesday
     */
    public void setTuesday(String tuesday) {
        this.tuesday = tuesday;
    }

    /**
     * getter for wednesday lessons
     * @return
     */
    public String getWednesday() {
        return wednesday;
    }

    /**
     * setter for wednesday lessons
     * @param wednesday
     */
    public void setWednesday(String wednesday) {
        this.wednesday = wednesday;
    }

    /**
     * getter for thursday lessons
     * @return
     */
    public String getThursday() {
        return thursday;
    }

    /**
     * setter for thursday lessons
     * @param thursday
     */
    public void setThursday(String thursday) {
        this.thursday = thursday;
    }

    /**
     * getter for friday lessons
     * @return
     */
    public String getFriday() {
        return friday;
    }

    /**
     * setter for friday lessons
     * @param friday
     */
    public void setFriday(String friday) {
        this.friday = friday;
    }

    /**
     * getter for saturday lessons
     * @return
     */
    public String getSaturday() {
        return saturday;
    }

    /**
     * setter for saturday lessons
     * @param saturday
     */
    public void setSaturday(String saturday) {
        this.saturday = saturday;
    }

    /**
     * Creates string representation of Schedule
     * @return string of Schedule
     */
    @Override
    public String toString() {
        return "Schedule:" +
                "\nid owner: "+ idOwner +
                "\npass owner: "+ passOwner +
                "\nsunday: " + sunday +
                "\nmonday: " + monday +
                "\ntuesday: " + tuesday +
                "\nwednesday: " + wednesday +
                "\nthursday: " + thursday +
                "\nfriday: " + friday +
                "\nsaturday: " + saturday+"\n";
    }
}
