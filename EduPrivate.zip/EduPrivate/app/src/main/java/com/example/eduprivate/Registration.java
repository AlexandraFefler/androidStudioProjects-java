package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;

public class Registration extends AppCompatActivity implements View.OnClickListener {
    /**
     * @author Alexandra Fefler
     * This activity allows to complete first step of registration
     */
    EditText etID, etName, etPass, etPhone, etEmail;
    Switch swIsTeacher;
    Button btnNext, btnShowPassword;
    TextView tvTitle;
    AutoCompleteTextView actvAddress;
    ImageView ivPfp;
    public static final int REQUEST_ID_MULTIPLE_PERMISSIONS = 1;
    Uri displayedImage;

    String[] addresses;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    ArrayList<String> basicInfoArr = new ArrayList<String>();

    boolean isSettings = false, isTeacher = false;
    String userID = "", userPass = "";
    String oldUserID = "", oldUserPass = "";
    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        etID = findViewById(R.id.etID);
        etName = findViewById(R.id.etRegName);
        etPass = findViewById(R.id.etRegPass);
        etPhone = findViewById(R.id.etRegPhone);
        etEmail = findViewById(R.id.etRegEmail);
        swIsTeacher = findViewById(R.id.swIsTeacher);
        btnNext = findViewById(R.id.btnNext);
        btnShowPassword = findViewById(R.id.btnShowPassword2);
        tvTitle = findViewById(R.id.tvTitle);
        ivPfp = findViewById(R.id.IVProfilePic);

        ivPfp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(checkAndRequestPermissions(Registration.this)){
                    chooseImage(Registration.this);
                }
            }
        });

        addresses = new String[] {"Tel Aviv", "Jerusalem", "Beer Sheva", "Netanya", "Haifa", "Eilat", "Rishon Le Tzion", "Holon", "Petah Tikva", "Bat Yam", "Ashkelon", "Ashdod"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_dropdown_item_1line, addresses);
        actvAddress = (AutoCompleteTextView) findViewById(R.id.actvAddress);
        actvAddress.setAdapter(adapter);

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        Intent take = getIntent();
        isTeacher = take.getBooleanExtra("isTeacher", false); //if not from teacher/student profile, then it's false
        userID = take.getStringExtra("ID"); //if not from teacher/student profile, then it's null
        userPass = take.getStringExtra("Pass"); //if not from teacher/student profile, then it's null
        oldUserID = userID; //saving previous info in case it is changed by user, so I can find their line in DB to upd.
        oldUserPass = userPass;
        isSettings = (userID != null && userPass != null); //if there are id and pass saved - then the user got here from the Profile activity

        if (isSettings){
            //find user's ID and password -> put them into the matching fields
            showExistingUserData();
            //disable switch and teachingSubjects part / make them invisible
            swIsTeacher.setVisibility(View.INVISIBLE);
            tvTitle.setText("Change your personal info");
            tvTitle.setTextSize(25);
        }

        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSettings){ //if in settings mode, don't check if user already exists
                    if(swIsTeacher.isChecked()){
                        if(check()){
                                if (!basicInfoArr.isEmpty()) {
                                    Intent goRegTeacher = new Intent(Registration.this, RegistrationTeacher.class);
                                    goRegTeacher.putExtra("info", basicInfoArr);
                                    goRegTeacher.putExtra("isSettings", true);
                                    goRegTeacher.putExtra("oldUserID",userID);
                                    goRegTeacher.putExtra("oldUserPass",userPass);
                                    startActivity(goRegTeacher);
                                }
                            else{
                                Toast.makeText(Registration.this, "User already exists, try a different password or ID", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                    else{
                        if(check()){
                                if (!basicInfoArr.isEmpty()) {
                                    Intent goRegStudent = new Intent(Registration.this, RegistrationStudent.class);
                                    goRegStudent.putExtra("info", basicInfoArr);
                                    goRegStudent.putExtra("isSettings", true);
                                    goRegStudent.putExtra("oldUserID",userID);
                                    goRegStudent.putExtra("oldUserPass",userPass);
                                    startActivity(goRegStudent);
                                }
                            else{
                                Toast.makeText(Registration.this, "User already exists, try a different password or ID", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }
                else{
                    if(swIsTeacher.isChecked()){
                        if(check()){
                            if (!userExists()){
                                if (!basicInfoArr.isEmpty()) {
                                    Intent goRegTeacher = new Intent(Registration.this, RegistrationTeacher.class);
                                    goRegTeacher.putExtra("info", basicInfoArr);
                                    startActivity(goRegTeacher);
                                }
                            }
                            else{
                                Toast.makeText(Registration.this, "User already exists, try a different password or ID", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                    else{
                        if(check()){
                            if (!userExists()){
                                if (!basicInfoArr.isEmpty()) {
                                    Intent goRegStudent = new Intent(Registration.this, RegistrationStudent.class);
                                    goRegStudent.putExtra("info", basicInfoArr);
                                    startActivity(goRegStudent);
                                }
                            }
                            else{
                                Toast.makeText(Registration.this, "User already exists, try a different password or ID", Toast.LENGTH_LONG).show();
                            }
                        }
                    }
                }

            }
        });

        btnShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnShowPassword.getText().toString().equals("Show password")){
                    etPass.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    btnShowPassword.setText("Hide password");
                }
                else{
                    etPass.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    btnShowPassword.setText("Show password");
                }
            }
        });
    }
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();


        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Checks if user exists
     * @return true if user exists
     */
    private boolean userExists() {
        boolean flag=false;
        String strID = etID.getText().toString();
        String strPass = etPass.getText().toString();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            if (strID.equals(s1) && strPass.equals(s2)) {
                flag = true;
            }
            c.moveToNext();
        }
        sqdb.close();
        return flag;
    }

    /**
     * Checks if all filled fields are valid
     * @return true if all fields are valid
     */
    private boolean check() {
        String strID = etID.getText().toString();
        String strName = etName.getText().toString();
        String strPass = etPass.getText().toString();
        String strPhone = etPhone.getText().toString();
        String strEmail = etEmail.getText().toString();
        String strAddress = actvAddress.getText().toString();
        String strPic = "";
        if (displayedImage != null){
            strPic = displayedImage.toString();
        }

        String errorInfo = "";

        if(!idCheck(strID)){
            errorInfo += "\nID";
            // if id is not valid, turn the field to red
            etID.setBackgroundColor(Color.parseColor("#90D60056"));
            etID.setTextColor(Color.parseColor("#DF92B5"));
        }
        else{
            // if id is valid, turn field to white
            etID.setBackgroundColor(Color.parseColor("#00D60056"));
            etID.setTextColor(Color.parseColor("#CDDAFB"));
        }

        if(!nameCheck(strName)){
            errorInfo += "\nname";
            etName.setBackgroundColor(Color.parseColor("#90D60056"));
            etName.setTextColor(Color.parseColor("#DF92B5"));
        }
        else{
            etName.setBackgroundColor(Color.parseColor("#00D60056"));
            etName.setTextColor(Color.parseColor("#CDDAFB"));
        }

        if(!passwordCheck(strPass)){
            errorInfo += "\npassword";
            etPass.setBackgroundColor(Color.parseColor("#90D60056"));
            etPass.setTextColor(Color.parseColor("#DF92B5"));
        }
        else{
            etPass.setBackgroundColor(Color.parseColor("#00D60056"));
            etPass.setTextColor(Color.parseColor("#CDDAFB"));
        }
        if(!phoneCheck(strPhone)){
            errorInfo += "\nphone";
            etPhone.setBackgroundColor(Color.parseColor("#90D60056"));
            etPhone.setTextColor(Color.parseColor("#DF92B5"));
        }
        else{
            etPhone.setBackgroundColor(Color.parseColor("#00D60056"));
            etPhone.setTextColor(Color.parseColor("#CDDAFB"));
        }
        if(!emailCheck(strEmail)){
            errorInfo += "\nemail";
            etEmail.setBackgroundColor(Color.parseColor("#90D60056"));
            etEmail.setTextColor(Color.parseColor("#DF92B5"));
        }
        else{
            etEmail.setBackgroundColor(Color.parseColor("#00D60056"));
            etEmail.setTextColor(Color.parseColor("#CDDAFB"));
        }
        if(!addressCheck(strAddress)){
            errorInfo += "\naddress";
            actvAddress.setBackgroundColor(Color.parseColor("#90D60056"));
            actvAddress.setTextColor(Color.parseColor("#DF92B5"));
        }
        else{
            actvAddress.setBackgroundColor(Color.parseColor("#00D60056"));
            actvAddress.setTextColor(Color.parseColor("#CDDAFB"));
        }

        if (errorInfo.isEmpty()){
            Toast.makeText(this, "check passed", Toast.LENGTH_SHORT).show();
            //if check passed, add info into array for step 2 on a different activity
            basicInfoArr.clear();
            basicInfoArr.add(strID);
            basicInfoArr.add(strName);
            basicInfoArr.add(strPass);
            basicInfoArr.add(strPhone);
            basicInfoArr.add(strEmail);
            basicInfoArr.add(strAddress);
            basicInfoArr.add(strPic);
            return true;
        }
        else{
            AlertDialog.Builder adb;
            adb = new AlertDialog.Builder(this);
            adb.setTitle("Something's wrong");
            adb.setMessage("There's something wrong in the following fields: "+errorInfo + "\n - - to clear all fields press 'Cancel' - - ");
            adb.setIcon(R.drawable.iconimportant);
            adb.setCancelable(false);
            adb.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                }
            });
            adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    etID.setText("");
                    etName.setText("");
                    etPass.setText("");
                    etPhone.setText("");
                    etEmail.setText("");
                    actvAddress.setText("");
                    swIsTeacher.setChecked(false);
                }
            });
            AlertDialog adbb = adb.create();
            adbb.show();
        }
        return false;
    }

    /**
     * Checks if ID is valid
     * @param id
     * @return
     */
    private boolean idCheck(String id) {
        if (!id.isEmpty()){
            return id.length() == 9;
        }
        return false;
    }

    /**
     * Checks if name is valid
     * @param name
     * @return
     */
    private boolean nameCheck(String name) {
        //String nick = str;
        if (!name.isEmpty()){
            char[] chars = name.toCharArray();
            int count = 0; //counting only letters
            for (char c : chars){
                if (!Character.isLetter(c) && !Character.isSpaceChar(c)){
                    return false;
                }
                if (Character.isLetter(c)){
                    count++;
                }
            }
            return count > 1;
        }
        return false;
    }

    /**
     * Checks if password is valid
     * password requirements: 7 letters min, only english letters (A/a) and numbers allowed, no spaces and etc. //I'm too lazy for special chars
     * @param pass
     * @return
     */
    public boolean passwordCheck(String pass){
        if (!pass.isEmpty()){
            char[] chars = pass.toCharArray();
            int count = 0; //
            for (char c : chars){
                if (!Character.isLetter(c) && !Character.isDigit(c) && isEnglishLetter(c)){
                    return false;
                }
                else{
                    count++;
                }
            }
            return count >= 7;
        }
        return false;
    }

    /**
     * Checks if phone number is valid
     * @param tel
     * @return
     */
    public boolean phoneCheck(String tel){
        if (!tel.isEmpty()){ //if it's not empty, it has to meet the requirements
            if (tel.startsWith("0")){
                return tel.length() == 9 || tel.length() == 10;
            }
            else{
                if (tel.startsWith("+972")){
                    return tel.length() == 13;
                }
            }
        }
        else{ //if empty, it's fine too, and obviously there's no need in checking anything else
            return true;
        }
        return false; // if not empty and not passing the requirements - false
    }

    /**
     * Checks if email address is valid
     * @param email
     * @return
     */
    public boolean emailCheck(String email){
        if (!email.isEmpty()){
            if (!email.startsWith("@") && !email.endsWith("@") && countCharInString(email, '@') == 1 && email.contains(".")){
                //אם ההפרש בין מיקום תו אחד למיקום תו אחר גדול מאחד - סימן שיש ביניהם לפחות תו אחד
                //בנוסף הנקודה חייבת להיות אחרי השטרודל לפי מבנה של דוא"ל
                //לכן אם ההפרש בין מיקום הנקודה למקום השטרודל שלילי - סימן שהנקודה נמצאת רק לפני השטרודל
                return (email.lastIndexOf(".") - email.indexOf("@") > 1 );
            }
        }
        else{
            return true; //can be empty too
        }
        return false;
    }

    /**
     * counts how many times a char appears in a string
     * @param str
     * @param ch
     * @return
     */
    public int countCharInString(String str, char ch){
        int count = 0;
        for (int i = 0; i<str.length(); i++){
            if (ch == (str.charAt(i))){
                count++;
            }
        }
        return count;
    }

    /**
     * Checks if char is in range of A-Z or a-z
     * @param c
     * @return
     */
    public boolean isEnglishLetter(char c){
        return (!((c>='a' &&c<='z')||c>='A' &&c<='Z')||c>='0' &&c<='9');
    }

    /**
     * checks if address is from list
     * @param address
     * @return
     */
    //
    public boolean addressCheck(String address){
        if (!address.isEmpty()){
                for (int i = 0; i<addresses.length; i++) {
                    if (addresses[i].equals(address))
                        return true;
                }
                return false;
        }
        else{
            return true;
        }
    }

    /**
     *
     * If activity is in settings mode, show logged in user data
     */
    private void showExistingUserData(){
        boolean flag = false;

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            if (userID.equals(s1) && userPass.equals(s3)) {
                flag = true;
                boolean isTeacher = false;
                if (c.getString(col8).equals("true")) {
                    isTeacher = true;
                }

                etID.setText(s1);
                etName.setText(s2);
                etPass.setText(s3);
                if (s4 != null){
                    etPhone.setText(s4);
                }
                else{
                    etPhone.setText("");
                }
                if (s5 != null){
                    etEmail.setText(s5);
                }
                else{
                    etEmail.setText("");
                }
                swIsTeacher.setChecked(isTeacher);

                if(!s7.isEmpty()){
                    Bitmap bitmap = null;
                    try {
                        bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), Uri.parse(s7));
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    ivPfp.setImageBitmap(bitmap);
                }
                else{
                    int imgRes = getResources().getIdentifier("@drawable/defaultprofilepic", null, getPackageName());
                    ivPfp.setImageDrawable(getResources().getDrawable(imgRes));
                }
            }
            c.moveToNext();
        }
        sqdb.close();
    }

    /**
     * Checks and requests camera and internal storage permissions
     * @param context
     * @return
     */
    public static boolean checkAndRequestPermissions(final Activity context) {
        int WExtstorePermission = ContextCompat.checkSelfPermission(context,
                Manifest.permission.WRITE_EXTERNAL_STORAGE);
        int cameraPermission = ContextCompat.checkSelfPermission(context,
                Manifest.permission.CAMERA);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (cameraPermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(Manifest.permission.CAMERA);
        }
        if (WExtstorePermission != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded
                    .add(Manifest.permission.WRITE_EXTERNAL_STORAGE);
        }
        if (!listPermissionsNeeded.isEmpty()) {
            ActivityCompat.requestPermissions(context, listPermissionsNeeded
                            .toArray(new String[listPermissionsNeeded.size()]),
                    REQUEST_ID_MULTIPLE_PERMISSIONS);
            return false;
        }
        return true;
    }

    /**
     * Chooses image from gallery or camera
     * @param context
     */
    private void chooseImage(Context context){
        final CharSequence[] optionsMenu = {"Take Photo", "Choose from Gallery", "Exit" }; // create a menuOption Array
        // create a dialog for showing the optionsMenu
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        // set the items in builder
        builder.setItems(optionsMenu, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                if(optionsMenu[i].equals("Take Photo")){
                    // Open the camera and get the photo
                    Intent takePicture = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
                    startActivityForResult(takePicture, 0);
                }
                else if(optionsMenu[i].equals("Choose from Gallery")){
                    // choose from  external storage
                    Intent pickPhoto = new Intent(Intent.ACTION_PICK, android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                    startActivityForResult(pickPhoto , 1);
                }
                else if (optionsMenu[i].equals("Cancel")) {
                    dialogInterface.dismiss();
                }
            }
        });
        builder.show();
    }

    /**
     * Makes Toast of permission is not given
     * @param requestCode
     * @param permissions
     * @param grantResults
     */
    @Override
    public void onRequestPermissionsResult(int requestCode,String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode,permissions,grantResults);
        switch (requestCode) {
            case REQUEST_ID_MULTIPLE_PERMISSIONS:
                if (ContextCompat.checkSelfPermission(Registration.this,
                        Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(),
                            "FlagUp Requires Access to Camara.", Toast.LENGTH_SHORT)
                            .show();
                } else if (ContextCompat.checkSelfPermission(Registration.this,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(getApplicationContext(),
                            "FlagUp Requires Access to Your Storage.",
                            Toast.LENGTH_SHORT).show();
                } else {
                    chooseImage(Registration.this);
                }
                break;
        }
    }

    /**
     * Uploads chosen image to image view
     * @param requestCode
     * @param resultCode
     * @param data
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_CANCELED) {
            switch (requestCode) {
                case 0:
                    if (resultCode == RESULT_OK && data != null) {
                        Bitmap selectedImage = (Bitmap) data.getExtras().get("data");
                        displayedImage = getImageUri(this, selectedImage);
                        ivPfp.setImageBitmap(selectedImage);
                    }
                    break;
                case 1:
                    if (resultCode == RESULT_OK && data != null) {
                        Uri selectedImage = data.getData();
                        String[] filePathColumn = {MediaStore.Images.Media.DATA};
                        if (selectedImage != null) {
                            Cursor cursor = getContentResolver().query(selectedImage, filePathColumn, null, null, null);
                            if (cursor != null) {
                                cursor.moveToFirst();
                                int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
                                String picturePath = cursor.getString(columnIndex);
                                ivPfp.setImageBitmap(BitmapFactory.decodeFile(picturePath));
                                displayedImage = getImageUri(this, BitmapFactory.decodeFile(picturePath));
                                cursor.close();
                            }
                        }
                    }
                    break;
            }
        }
    }

    /**
     * Gets image URI from a Bitmap
     * @param inContext
     * @param inImage
     * @return
     */
    public Uri getImageUri(Context inContext, Bitmap inImage) {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream();
        inImage.compress(Bitmap.CompressFormat.JPEG, 100, bytes);
        String path = MediaStore.Images.Media.insertImage(inContext.getContentResolver(), inImage, "Title", null);
        return Uri.parse(path);
    }

    @Override
    public void onClick(View v) {

    }
}