package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.nio.file.NotLinkException;
import java.util.ArrayList;

public class NotifsAndSchedulesLists extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows lists of all notifications and all schesules
     */
    ListView lvNotifs;
    ArrayAdapter<Notification> adapterNotifs;
    ArrayList<Notification> notifsAL;
    Notification notif;

    ListView lvSchedules;
    ArrayAdapter<Schedule> adapterSchedules;
    ArrayList<Schedule> schedulesAL;
    Schedule schedule;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifs_and_schedules_lists);
        lvNotifs = findViewById(R.id.lvNotifs);
        lvSchedules = findViewById(R.id.lvSchedule);

        notifsAL = new ArrayList<>();
        schedulesAL = new ArrayList<>();

        my_db = new DBHelper(this);
        showNotifs();
        showSchedules();
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }

    /**
     * Shows list of notifications on list view
     */
    private void showNotifs() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_NOTIFICATIONS, null, null, null, null, null, null);

        int col1 = c.getColumnIndex(DBHelper.IDRECEIVER);
        int col2 = c.getColumnIndex(DBHelper.PASSRECEIVER);
        int col3 = c.getColumnIndex(DBHelper.NOTIFICATIONTEXT);
        int col4 = c.getColumnIndex(DBHelper.LESSONDAY);
        int col5 = c.getColumnIndex(DBHelper.LESSONHOUR);
        int col6 = c.getColumnIndex(DBHelper.LESSONSUBJECT);
        int col7 = c.getColumnIndex(DBHelper.OTHERID);
        int col8 = c.getColumnIndex(DBHelper.OTHERPASS);
        int col9 = c.getColumnIndex(DBHelper.NOTIFICATIONTYPE);
        int col10 = c.getColumnIndex(DBHelper.ISACTIVE);


        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);

            boolean isActiveBool = s10.equals("true");

            notif = new Notification(s1, s2, s3, s4, s5, s6, s7, s8, s9,isActiveBool);
            notifsAL.add(notif);

            c.moveToNext();
        }
        sqdb.close();

        adapterNotifs = new ArrayAdapter<Notification>(this, android.R.layout.simple_list_item_1, notifsAL);
        lvNotifs.setAdapter(adapterNotifs);
    }

    /**
     * Shows list of schedules on list view
     */
    private void showSchedules() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_SCHEDULES, null, null, null, null, null, null);

        int col1 = c.getColumnIndex(DBHelper.IDOWNER);
        int col2 = c.getColumnIndex(DBHelper.PASSOWNER);
        int col3 = c.getColumnIndex(DBHelper.SUNDAY);
        int col4 = c.getColumnIndex(DBHelper.MONDAY);
        int col5 = c.getColumnIndex(DBHelper.TUESDAY);
        int col6 = c.getColumnIndex(DBHelper.WEDNESDAY);
        int col7 = c.getColumnIndex(DBHelper.THURSDAY);
        int col8 = c.getColumnIndex(DBHelper.FRIDAY);
        int col9 = c.getColumnIndex(DBHelper.SATURDAY);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);

            schedule = new Schedule(s1, s2, s3, s4, s5, s6, s7, s8, s9);
            schedulesAL.add(schedule);

            c.moveToNext();
        }
        sqdb.close();

        adapterSchedules = new ArrayAdapter<Schedule>(this, android.R.layout.simple_list_item_1, schedulesAL);
        lvSchedules.setAdapter(adapterSchedules);
    }
}