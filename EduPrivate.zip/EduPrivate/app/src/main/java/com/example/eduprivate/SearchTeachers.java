package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.RadioButton;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;
import java.util.List;

public class SearchTeachers extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity allows to search for private teachers registeres in the system
     */
    String studentID = "", studentPass = "";
    EditText etSearchName;
    Button btnSearchName, btnSortSubj, btnResetSort, btnExpToChp, btnChpToExp, btnSortLvl1, btnSortLvl2, btnSortLvl3, btnSortLvl4, btnSortLvl5, btnSortLvl6, btnSortLvl7, btnSortLvl8, btnSortLvl9, btnSortLvl10, btnSortLvl11, btnSortLvl12, btnSortLvlOther;
    ListView lvSubjsToSort, lvResults;

    ArrayList<Teacher> teachersList;
    TeacherAdapter teachersAdapter;
    Teacher teacher;

    ArrayList<String> listArrTeachingSubjects;
    String subject = "";
    ArrayAdapter<String> adapterSubjs;
    String chosenSubjName = "";

    SQLiteDatabase sqdb;
    DBHelper my_db;
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }
    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_teachers);

        Intent take = getIntent();
        studentID = take.getStringExtra("studentID");
        studentPass = take.getStringExtra("studentPass");

        lvResults = findViewById(R.id.lvTeachersResults);
        teachersList = new ArrayList<>();
        my_db = new DBHelper(this);
        showUnsorted();

        //sort by level buttons
        {
            btnSortLvl1 = findViewById(R.id.btnSortLvl1);
            btnSortLvl2 = findViewById(R.id.btnSortLvl2);
            btnSortLvl3 = findViewById(R.id.btnSortLvl3);
            btnSortLvl4 = findViewById(R.id.btnSortLvl4);
            btnSortLvl5 = findViewById(R.id.btnSortLvl5);
            btnSortLvl6 = findViewById(R.id.btnSortLvl6);
            btnSortLvl7 = findViewById(R.id.btnSortLvl7);
            btnSortLvl8 = findViewById(R.id.btnSortLvl8);
            btnSortLvl9 = findViewById(R.id.btnSortLvl9);
            btnSortLvl10 = findViewById(R.id.btnSortLvl10);
            btnSortLvl11 = findViewById(R.id.btnSortLvl11);
            btnSortLvl12 = findViewById(R.id.btnSortLvl12);
            btnSortLvlOther = findViewById(R.id.btnSortLvlOther);

            btnSortLvl1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(1);
                }
            });
            btnSortLvl2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(2);
                }
            });
            btnSortLvl3.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(3);
                }
            });
            btnSortLvl4.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(4);
                }
            });
            btnSortLvl5.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(5);
                }
            });
            btnSortLvl6.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(6);
                }
            });
            btnSortLvl7.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(7);
                }
            });
            btnSortLvl8.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(8);
                }
            });
            btnSortLvl9.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(9);
                }
            });
            btnSortLvl10.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(10);
                }
            });
            btnSortLvl11.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(11);
                }
            });
            btnSortLvl12.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(12);
                }
            });
            btnSortLvlOther.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    showSortedByLevel(13);
                }
            });
        }

        lvResults.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent goRequest = new Intent(SearchTeachers.this, RequestLesson.class);
                goRequest.putExtra("studentID", studentID);
                goRequest.putExtra("studentPass", studentPass);
                goRequest.putExtra("teacherID", teachersList.get(position).getID());
                goRequest.putExtra("teacherPass", teachersList.get(position).getPassword());
                startActivity(goRequest);
            }
        });

        lvSubjsToSort = findViewById(R.id.lvSubjectsToSort);
        lvSubjsToSort.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                chosenSubjName = listArrTeachingSubjects.get(position);
            }
        });

        listArrTeachingSubjects = new ArrayList<String>();
        showAllSubjects();
        btnSortSubj = findViewById(R.id.btnSortBySubject);
        btnSortSubj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSortedBySubjName();
            }
        });

        btnExpToChp = findViewById(R.id.btnSortFromExpensive);
        btnExpToChp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSortedByPrice(true);
            }
        });

        btnChpToExp = findViewById(R.id.btnSortFromCheap);
        btnChpToExp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSortedByPrice(false);
            }
        });

        etSearchName = findViewById(R.id.etSearchByBName);
        btnSearchName = findViewById(R.id.btnSearchByName);
        btnSearchName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showSortedByName();
            }
        });

        btnResetSort = findViewById(R.id.btnResetSort);
        btnResetSort.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showUnsorted();
            }
        });
    }

    /**
     * Shows teachers in list view, sorted by Cursor
     * @param c
     */
    private void showTeachers(Cursor c){
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);
        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);


        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);
            String s11 = c.getString(col11);
            String s12 = c.getString(col12);

            boolean isTeacher = false;
            if (s8.equals("true")){
                isTeacher = true;
            }

            int priceInt = 0;
            if (!s10.isEmpty()){
                priceInt = Integer.parseInt(s10);
            }

            teacher = new Teacher(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9, priceInt, s11, s12);
            teachersList.add(teacher);


            c.moveToNext();
        }
        sqdb.close();

        teachersAdapter = new TeacherAdapter(this, R.layout.custom_list_teachers,this.teachersList);
        lvResults.setAdapter(teachersAdapter);
    }

    /**
     * Shows all teachers
     */
    private void showUnsorted(){
        teachersList.clear();
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        showTeachers(c);
    }

    /**
     * Shows all subjects of all teachers in list view
     */
    private void showAllSubjects() {
        listArrTeachingSubjects.clear();
        String allSubjects = "";

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();

        while (!c.isAfterLast()) {
            String s3 = c.getString(col3);

            if(!s3.isEmpty()){ //if there is at least one ts
                allSubjects += s3;
            }
            else{
                listArrTeachingSubjects.add("--No subjects found--");
            }
            c.moveToNext();
        }
        sqdb.close();

        //decipher the string into an arrayList
        String[] arrAllSubjs = allSubjects.split("@");
        listArrTeachingSubjects.clear(); //since it saves the list of ts's from before pressing "upd subj"
        Collections.addAll(listArrTeachingSubjects, arrAllSubjs); //since i can't split a srting straight into the list (& not array) as i need
        for (int i=0; i<listArrTeachingSubjects.size(); i++){
            if (!listArrTeachingSubjects.get(i).isEmpty()){ //if it's empty then its a "@@" case which appears between subjLists of diff teachers
                subject = listArrTeachingSubjects.get(i);
                String[] splittedSubj = subject.split("_");
                listArrTeachingSubjects.set(i, splittedSubj[0]); //need only name
            }
            else {
                listArrTeachingSubjects.remove(i);
            }
            listArrTeachingSubjects = removeDublicates(listArrTeachingSubjects);
        }

        //put the array list into the lv
        adapterSubjs = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listArrTeachingSubjects);
        lvSubjsToSort.setAdapter(adapterSubjs);
    }

    /**
     * Removes duplicates of subjects in list of all subjects
     * @param al
     * @return
     */
    private ArrayList<String> removeDublicates(ArrayList<String> al) {
        ArrayList<String> resultAL = new ArrayList<String>();
        for (int i=0; i<al.size(); i++){
            if (!resultAL.contains(al.get(i))){
                resultAL.add(al.get(i));
            }
        }
        return resultAL;
    }

    /**
     * Shows teacher list sorted by name
     */
    private void showSortedByName() {
        teachersList.clear();
        String name = etSearchName.getText().toString();
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, DBHelper.NAME+"=?", new String[] {name}, null, null, null);
        showTeachers(c);
    }

    /**
     * Shows teacher list sorted by subject name
     */
    private void showSortedBySubjName() {
        teachersList.clear();
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);
        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);
            String s11 = c.getString(col11);
            String s12 = c.getString(col12);

            if (s12.contains(chosenSubjName)){
                boolean isTeacher = false;
                if (s8.equals("true")){
                    isTeacher = true;
                }

                int priceInt = 0;
                if (!s10.isEmpty()){
                    priceInt = Integer.parseInt(s10);
                }

                teacher = new Teacher(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9, priceInt, s11, s12);
                teachersList.add(teacher);
            }

            c.moveToNext();
        }
        sqdb.close();

        teachersAdapter = new TeacherAdapter(this, R.layout.custom_list_teachers,this.teachersList); //R.id.tvName, R.id.tvWeight, ??
        lvResults.setAdapter(teachersAdapter);
    }

    /**
     * Shows teacher list sorted by price
     * @param isExpToChp is the sort from expensive to cheap or the other way around
     */
    private void showSortedByPrice(boolean isExpToChp){
        teachersList.clear();
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);
        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);
            String s11 = c.getString(col11);
            String s12 = c.getString(col12);

            boolean isTeacher = false;
            if (s8.equals("true")){
                isTeacher = true;
            }

            int priceInt = 0;
            if (!s10.isEmpty()){
                priceInt = Integer.parseInt(s10);
            }

            teacher = new Teacher(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9, priceInt, s11, s12);
            teachersList.add(teacher);

            c.moveToNext();
        }
        sqdb.close();

        if(isExpToChp){
            Collections.sort(teachersList, new Comparator<Teacher>() {
                @Override public int compare(Teacher t1, Teacher t2) {
                    return t2.getPrice()- t1.getPrice();
                }
            });
        }
        else{
            Collections.sort(teachersList, new Comparator<Teacher>() {
                @Override public int compare(Teacher t1, Teacher t2) {
                    return t1.getPrice()- t2.getPrice();
                }
            });
        }

        teachersAdapter = new TeacherAdapter(this, R.layout.custom_list_teachers,this.teachersList); //R.id.tvName, R.id.tvWeight, ??
        lvResults.setAdapter(teachersAdapter);
    }

    /**
     * Shows teacher list sorted by level (of subject)
     * @param lvl
     */
    private void showSortedByLevel(int lvl) {
        teachersList.clear();
        boolean isStillOther = true;
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);
        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);
            String s11 = c.getString(col11);
            String s12 = c.getString(col12);

            if (s12.contains(lvl+" grade")){
                boolean isTeacher = false;
                if (s8.equals("true")){
                    isTeacher = true;
                }

                int priceInt = 0;
                if (!s10.isEmpty()){
                    priceInt = Integer.parseInt(s10);
                }

                teacher = new Teacher(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9, priceInt, s11, s12);
                teachersList.add(teacher);
            }

            isStillOther = true;
            if (lvl == 13 && isStillOther){
                for (int i=1; i<=12; i++){
                    if (s12.contains(i+" grade")){
                        isStillOther = false;
                    }
                }
                if (isStillOther){
                    boolean isTeacher = false;
                    if (s8.equals("true")){
                        isTeacher = true;
                    }

                    int priceInt = 0;
                    if (!s10.isEmpty()){
                        priceInt = Integer.parseInt(s10);
                    }

                    teacher = new Teacher(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9, priceInt, s11, s12);
                    teachersList.add(teacher);
                }
            }

            c.moveToNext();
        }
        sqdb.close();

        teachersAdapter = new TeacherAdapter(this, R.layout.custom_list_teachers,this.teachersList); //R.id.tvName, R.id.tvWeight, ??
        lvResults.setAdapter(teachersAdapter);
    }
}