package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RegistrationStudent extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity allows to register as a student
     */
    ArrayList infoBasic;
    EditText etExtraComments;
    Button btnInsert;
    TextView tvTitle;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    int regCounter = 0;
    boolean isSettings = false;
    String oldStudentID = "", oldStudentPass = "";

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_student);

        etExtraComments = findViewById(R.id.etExtraCommentsStudent);
        btnInsert = findViewById(R.id.btnRegisterStudent);
        tvTitle = findViewById(R.id.tvTitle);

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        Intent take = getIntent();
        infoBasic = (ArrayList<String>)take.getStringArrayListExtra("info");
        isSettings = take.getBooleanExtra("isSettings", false); //gets information about the mode - if it's settings or registration
        oldStudentID = take.getStringExtra("oldUserID");
        oldStudentPass = take.getStringExtra("oldUserPass");

        if(isSettings){
            showExistingStudentData();
            btnInsert.setText("Save changes");
            btnInsert.setTextSize(27);
            tvTitle.setText("Change your personal info");
            tvTitle.setTextSize(25);
        }

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSettings){
                        UpdateData();
                }
                else{
                    if (regCounter == 0){
                        insertData();
                        regCounter++;
                    }
                    else{
                        Toast.makeText(RegistrationStudent.this, "You can't register twice", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

    }

    /**
     * If activity is in settings mode, show logged in user data
     */
    private void showExistingStudentData() {
        boolean flag = false;

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            if (oldStudentID.equals(s1) && oldStudentPass.equals(s2)) {
                flag = true;
                etExtraComments.setText(s3);
            }
            c.moveToNext();
        }
        sqdb.close();
    }

    /**
     * If activity is in settings mode, update logged in user's wor in database
     */
    private void UpdateData() {
        //update data for existing line in DB
        String strExtraComments = etExtraComments.getText().toString();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(my_db.ID, infoBasic.get(0).toString());
        cv.put(my_db.NAME, infoBasic.get(1).toString());
        cv.put(my_db.PASSWORD, infoBasic.get(2).toString());
        cv.put(my_db.PHONE, infoBasic.get(3).toString());
        cv.put(my_db.EMAIL, infoBasic.get(4).toString());
        cv.put(my_db.ADDRESS, infoBasic.get(5).toString());
        cv.put(my_db.PIC, infoBasic.get(6).toString());
        cv.put(my_db.ISTEACHER, "false"); //if it's in student registration activity, the user is not a teacher
        cv.put(my_db.EXTRACOMMENTS, strExtraComments);

        sqdb.update(DBHelper.TABLE_ALL_USERS, cv, DBHelper.ID+"=? AND "+DBHelper.PASSWORD+"=?", new String[]{oldStudentID, oldStudentPass});
        sqdb.close();

        Toast.makeText(this, "User updated in system", Toast.LENGTH_SHORT).show();
    }
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * Inserts user data into database
     */
    private void insertData() {
        String strExtraComments = etExtraComments.getText().toString();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(my_db.ID, infoBasic.get(0).toString());
        cv.put(my_db.NAME, infoBasic.get(1).toString());
        cv.put(my_db.PASSWORD, infoBasic.get(2).toString());
        cv.put(my_db.PHONE, infoBasic.get(3).toString());
        cv.put(my_db.EMAIL, infoBasic.get(4).toString());
        cv.put(my_db.ADDRESS, infoBasic.get(5).toString());
        cv.put(my_db.PIC, infoBasic.get(6).toString());
        cv.put(my_db.ISTEACHER, "false"); //if it's in student registration activity, the user is not a teacher
        cv.put(my_db.EXTRACOMMENTS, strExtraComments);

        sqdb.insert(my_db.TABLE_ALL_USERS, null, cv);

        ContentValues cv2 = new ContentValues();
        cv2.put(my_db.IDOWNER, infoBasic.get(0).toString());
        cv2.put(my_db.PASSOWNER, infoBasic.get(2).toString());
        cv2.put(my_db.SUNDAY, "16:00@17:00@18:00@19:00@");
        cv2.put(my_db.MONDAY, "16:00@17:00@18:00@19:00@");
        cv2.put(my_db.TUESDAY, "16:00@17:00@18:00@19:00@");
        cv2.put(my_db.WEDNESDAY, "16:00@17:00@18:00@19:00@");
        cv2.put(my_db.THURSDAY, "16:00@17:00@18:00@19:00@");
        cv2.put(my_db.FRIDAY, "16:00@17:00@18:00@19:00@");
        cv2.put(my_db.SATURDAY, "16:00@17:00@18:00@19:00@");

        sqdb.insert(my_db.TABLE_SCHEDULES, null, cv2);

        sqdb.close();

        Toast.makeText(this, "User registered in system", Toast.LENGTH_SHORT).show();
        etExtraComments.setText("");
    }
}