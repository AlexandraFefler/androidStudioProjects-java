package com.example.eduprivate;

import android.widget.Toast;

public class Lesson {
    /**
     * @author Alexandra Fefler
     * This class represents a lesson and it's properties
     */
    private String startHour;
    private String subjectName;
    private String subjectLevel;
    private String studentID;
    private String studentPass;
    private String teacherID;
    private String teacherPass;
    private String day;

    /**
     * Creates a Lesson object
     * @param startHour
     * @param subjectName
     * @param subjectLevel
     * @param studentID
     * @param studentPass
     * @param teacherID
     * @param teacherPass
     * @param day
     */
    public Lesson(String startHour, String subjectName, String subjectLevel, String studentID, String studentPass, String teacherID, String teacherPass, String day) {
        this.startHour = startHour;
        this.subjectName = subjectName;
        this.subjectLevel = subjectLevel;
        this.studentID = studentID;
        this.studentPass = studentPass;
        this.teacherID = teacherID;
        this.teacherPass = teacherPass;
        this.day = day;
    }

    /**
     * Getter for subject name
     * @return subject name
     */
    public String getSubjectName() {
        return subjectName;
    }
    /**
     * Setter for subject Name
     * @param subjectName
     */
    public void setSubjectName(String subjectName) {
        this.subjectName = subjectName;
    }
    /**
     * Getter for subject level
     * @return subject level
     */
    public String getSubjectLevel() {
        return subjectLevel;
    }
    /**
     * Setter for subject Level
     * @param subjectLevel
     */
    public void setSubjectLevel(String subjectLevel) {
        this.subjectLevel = subjectLevel;
    }
    /**
     * Getter for starting hour
     * @return subject starting hour
     */
    public String getStartHour() {
        return startHour;
    }
    /**
     * Setter for start Hour
     * @param startHour
     */
    public void setStartHour(String startHour) {
        this.startHour = startHour;
    }
    /**
     * Getter for student ID
     * @return student ID
     */
    public String getStudentID() {
        return studentID;
    }
    /**
     * Setter for student ID
     * @param studentID
     */
    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }
    /**
     * Getter for student password
     * @return student password
     */
    public String getStudentPass() {
        return studentPass;
    }
    /**
     * Setter for student Pass
     * @param studentPass
     */
    public void setStudentPass(String studentPass) {
        this.studentPass = studentPass;
    }
    /**
     * Getter for teacher ID
     * @return teacher ID
     */
    public String getTeacherID() {
        return teacherID;
    }
    /**
     * Setter for teacher ID
     * @param teacherID
     */
    public void setTeacherID(String teacherID) {
        this.teacherID = teacherID;
    }
    /**
     * Getter for teacher password
     * @return teacher password
     */
    public String getTeacherPass() {
        return teacherPass;
    }
    /**
     * Setter for teacher Pass
     * @param teacherPass
     */
    public void setTeacherPass(String teacherPass) {
        this.teacherPass = teacherPass;
    }
    /**
     * Getter for day
     * @return day
     */
    public String getDay() {
        return day;
    }

    /**
     * Setter for day
     * @param day
     */
    public void setDay(String day) {
        this.day = day;
    }

    /**
     * Creates string representation of Lesson
     * @return string of Lesson
     */
    @Override
    public String toString() {
        return "Lesson:" +
                "\nsubjectName: "+ subjectName +
                "\nsubjectLevel: "+ subjectLevel +
                "\nstartHour: "+ startHour +
                "\nstudentID: "+ studentID +
                "\nstudentPass: " + studentPass +
                "\nteacherID: " + teacherID +
                "\nteacherPass: " + teacherPass +
                "\nday: " + day+"\n";
    }
}
