package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class RequestLesson extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity allows to request a lesson from a teacher
     */
    Button btnSendRequest;
    TextView requestedTeacherName;

    Spinner spSubjects;
    ArrayList<String> allSubjects;
    ArrayAdapter<String> adapterSubjects;
    String selectedSubject = "";

    Spinner spDays;
    ArrayList<String> allDays;
    ArrayAdapter<String> adapterDays;
    String selectedDay = "";

    Spinner spHours;
    ArrayList<String> allHours;
    ArrayAdapter<String> adapterHours;
    String selectedHour = "";

    SQLiteDatabase sqdb;
    DBHelper my_db;

    String studentID = "";
    String studentPass = "";
    String teacherID = "";
    String teacherPass = "";

    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish(); //back to previous window
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_lesson);

        Intent take = getIntent();
        studentID = take.getStringExtra("studentID");
        studentPass = take.getStringExtra("studentPass");
        teacherID = take.getStringExtra("teacherID");
        teacherPass = take.getStringExtra("teacherPass");

        requestedTeacherName = findViewById(R.id.tvRequestedTeacherName);
        btnSendRequest = findViewById(R.id.btnRequest);
        spSubjects = findViewById(R.id.spSubject);
        spDays = findViewById(R.id.spDay);
        spHours = findViewById(R.id.spHour);

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        allSubjects = new ArrayList<>();
        fillAllSubjects();
        spSubjects.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedSubject = allSubjects.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        allDays = new ArrayList<>();
        allDays.add("Sunday");
        allDays.add("Monday");
        allDays.add("Tuesday");
        allDays.add("Wednesday");
        allDays.add("Thursday");
        allDays.add("Friday");
        allDays.add("Saturday");
        adapterDays = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, allDays);
        spDays.setAdapter(adapterDays);
        spDays.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedDay = allDays.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        allHours = new ArrayList<>();
        allHours.add("16:00");
        allHours.add("17:00");
        allHours.add("18:00");
        allHours.add("19:00");
        adapterHours = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, allHours);
        spHours.setAdapter(adapterHours);
        spHours.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                selectedHour = allHours.get(position);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btnSendRequest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendStudentNotif();
                sendTeacherNotif();
                Toast.makeText(RequestLesson.this, "Lesson requested", Toast.LENGTH_SHORT).show();
            }
        });
    }

    /**
     * Sends the student a notification about the request
     */
    private void sendStudentNotif() {
        String[] splittedSubj = selectedSubject.split("_");
        String teacherName = getUserName(teacherID, teacherPass);
        String notifText = "You requested a lesson ("+splittedSubj[0]+", level - "+splittedSubj[1]+") at "+selectedDay+", "+selectedHour+" with "+teacherName+". ";
        SQLiteDatabase sqdb;
        DBHelper my_db;
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(my_db.IDRECEIVER, studentID);
        cv.put(my_db.PASSRECEIVER, studentPass);
        cv.put(my_db.NOTIFICATIONTEXT, notifText);
        cv.put(my_db.LESSONDAY, selectedDay);
        cv.put(my_db.LESSONHOUR, selectedHour);
        cv.put(my_db.LESSONSUBJECT, selectedSubject);
        cv.put(my_db.OTHERID, teacherID);
        cv.put(my_db.OTHERPASS, teacherPass);
        cv.put(my_db.NOTIFICATIONTYPE, "textonly");
        cv.put(my_db.ISACTIVE, "true");

        sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv);
    }
    /**
     * Sends the teacher a notification about the request
     */
    private void sendTeacherNotif() {
        String[] splittedSubj = selectedSubject.split("_");
        String studentName = getUserName(studentID, studentPass);
        String studentContactInfo = getUserContactInfo(studentID,studentPass);
        String notifText = studentName+" requested a lesson in "+splittedSubj[0]+", level - "+splittedSubj[1]+", at "+selectedDay+", "+selectedHour+".\nContact student:\n"+studentContactInfo;
        SQLiteDatabase sqdb;
        DBHelper my_db;
        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        ContentValues cv = new ContentValues();
        cv.put(my_db.IDRECEIVER, teacherID);
        cv.put(my_db.PASSRECEIVER, teacherPass);
        cv.put(my_db.NOTIFICATIONTEXT, notifText);
        cv.put(my_db.LESSONDAY, selectedDay);
        cv.put(my_db.LESSONHOUR, selectedHour);
        cv.put(my_db.LESSONSUBJECT, selectedSubject);
        cv.put(my_db.OTHERID, studentID);
        cv.put(my_db.OTHERPASS, studentPass);
        cv.put(my_db.NOTIFICATIONTYPE, "acceptdeclinebuttons");
        cv.put(my_db.ISACTIVE, "true");

        sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv);
    }

    /**
     * Creates a string of tel.number and email of user
     * @param id
     * @param pass
     * @return
     */
    private String getUserContactInfo(String id, String pass) {
        String str = "Tel.: ";
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.PHONE);
        int col4 = c.getColumnIndex(DBHelper.EMAIL);

        c.moveToFirst();

        while (!c.isAfterLast()) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);

            if (id.equals(s1) && pass.equals(s2)){
                if (s3.isEmpty()){
                    s3 = "-";
                }
                if (s4.isEmpty()){
                    s4 = "-";
                }
                return str+s3+"\nEmail: "+s4;
            }
            c.moveToNext();
        }
        sqdb.close();
        return str+"-\nEmail:-";
    }

    /**
     * Gets name of user
     * @param id
     * @param pass
     * @return
     */
    private String getUserName(String id, String pass) {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.NAME);

        c.moveToFirst();

        while (!c.isAfterLast()) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);

            if (id.equals(s1) && pass.equals(s2)){
                return s3;
            }
            c.moveToNext();
        }
        sqdb.close();
        return "no name";
    }

    /**
     * Fills spinner list with teacher's teaching subjets
     */
    private void fillAllSubjects() {
        allSubjects.clear();

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);
        int col4 = c.getColumnIndex(DBHelper.NAME);

        c.moveToFirst();

        while (!c.isAfterLast()) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);

            if (teacherID.equals(s1) && teacherPass.equals(s2)){
                if(!s3.isEmpty()){ //if there is at least one ts
                    //decipher the string into an arrayList
                    String[] arrAllSubjs = s3.split("@");
                    allSubjects.clear(); //since it saves the list of ts's from before pressing "upd subj"
                    Collections.addAll(allSubjects, arrAllSubjs);
                }
                else{
                    allSubjects.add("This teacher doesn't have subjects to suggest");
                }
                requestedTeacherName.setText("Teacher: "+s4);
            }
            c.moveToNext();
        }
        sqdb.close();

        adapterSubjects = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, allSubjects);
        spSubjects.setAdapter(adapterSubjects);
    }
}