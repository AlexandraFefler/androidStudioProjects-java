package com.example.eduprivate;

public class Teacher extends User{
    /**
     * @author Alexandra Fefler
     * This class represents a teacher user and their information
     */
    private int price;
    private String experience;
    private String teachingsubjects;

    /**
     * Creates a Teacher object
     * @param id
     * @param name
     * @param password
     * @param phone
     * @param email
     * @param address
     * @param pic
     * @param isTeacher
     * @param extraComments
     * @param price
     * @param experience
     * @param teachingsubjects
     */
    public Teacher(String id, String name, String password, String phone, String email, String address, String pic, boolean isTeacher, String extraComments, int price, String experience, String teachingsubjects) {
        super(id, name, password, phone, email, address, pic, isTeacher, extraComments);
        this.price = price;
        this.experience = experience;
        this.teachingsubjects = teachingsubjects;
    }

    /**
     * Getter for price of lesson
     * @return price of lesson
     */
    public int getPrice() {
        return price;
    }

    /**
     * setter for price of lesson
     * @param price
     */
    public void setPrice(int price) {
        this.price = price;
    }

    /**
     * Getter for teachers work experience
     * @return
     */
    public String getExperience() {
        return experience;
    }

    /**
     * Setter for teachers work experience
     * @param experience teachers work experience
     */
    public void setExperience(String experience) {
        this.experience = experience;
    }

    /**
     * Getter for the subjects the teacher teaches
     * @return
     */
    public String getTeachingsubjects() {
        return teachingsubjects;
    }

    /**
     * Setter for the subjects the teacher teaches
     * @param teachingsubjects
     */
    public void setTeachingsubjects(String teachingsubjects) {
        this.teachingsubjects = teachingsubjects;
    }

    /**
     * Creates string representation of Teacher
     * @return string of Teacher
     */
        @Override
    public String toString() {
        return super.toString()+"\n-Teacher info-" +
                "\nprice: " + price +
                "\nexperience: " + experience +
                "\nteachingsubjects: " + teachingsubjects + "\n";
    }
}
