package com.example.eduprivate;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.widget.Toast;

import java.util.Calendar;

public class WIFI_Receiver extends BroadcastReceiver {
    /**
     * @author Alexandra Fefler
     * This reciever checks if connection to WIFI is on
     */

    /**
     * When receives information from device, checks if connection to WIFI is on
     * If it is off then sends a notifications about it to device
     * @param context
     * @param intent
     */
    @Override
    public void onReceive(Context context, Intent intent) {
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Intent after;
        PendingIntent afterIntent;
        Calendar c;
        AlarmManager alma;
        Boolean isOn = isOnline(context);
        if (isOn) {
            Toast.makeText(context, "Connect to WiFi is on", Toast.LENGTH_SHORT).show();
            after = new Intent(context, NotifService.class);
            afterIntent = PendingIntent.getService(context, 0,after, 0);

            alma = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            c = Calendar.getInstance();
            c.setTimeInMillis(System.currentTimeMillis());
            c.add(Calendar.MILLISECOND, 1);
            alma.cancel(afterIntent);

        }
        else  {
            Toast.makeText(context, "Connect to WiFi is off", Toast.LENGTH_SHORT).show();
            after = new Intent(context, NotifService.class);
            afterIntent = PendingIntent.getService(context, 0,after, 0);

            alma = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);

            c = Calendar.getInstance();
            c.setTimeInMillis(System.currentTimeMillis());
            c.add(Calendar.MILLISECOND, 1);

            alma.set(AlarmManager.RTC_WAKEUP, c.getTimeInMillis(), afterIntent);
        }
    }

    /**
     * Checks if connection to WIFI is on
     * @param context
     * @return
     */
    public boolean isOnline(Context context) {
        try {
            ConnectivityManager cm = (ConnectivityManager) context.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo[] netInfo = cm.getAllNetworkInfo();
            Toast.makeText(context, ""+netInfo[1], Toast.LENGTH_SHORT).show();//wifi
            //should check null because in airplane mode it will be null
            return (netInfo != null && (netInfo[1].isConnected()));
        } catch (NullPointerException e) {
            Toast.makeText(context, e.toString(), Toast.LENGTH_SHORT).show();
            return false;
        }
    }
}
