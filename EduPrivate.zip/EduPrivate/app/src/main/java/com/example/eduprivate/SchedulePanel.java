package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class SchedulePanel extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows the lessons schedule
     */
    ListView lvSchedule;
    LessonAdapter adapterLessons;
    ArrayList<Lesson> allLessonsArrList;
    ArrayList<Lesson> lessonsOfTheDayArrList;
    Lesson lssn;

    String userID;
    String userPass;

    SQLiteDatabase sqdb;
    DBHelper my_db;
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish(); //back to previous window
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule_panel);

        Intent take = getIntent();
        userID = take.getStringExtra("ID");
        userPass = take.getStringExtra("Pass");

        lvSchedule = findViewById(R.id.lvSchedulesPanel);
        allLessonsArrList = new ArrayList<>();
        lessonsOfTheDayArrList = new ArrayList<>();


        my_db = new DBHelper(this);
        showSchedule();

        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }

    /**
     * Shows schedule in list view
     */
    private void showSchedule() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_SCHEDULES, null, null, null, null, null, null);

        int col1 = c.getColumnIndex(DBHelper.IDOWNER);
        int col2 = c.getColumnIndex(DBHelper.PASSOWNER);
        int col3 = c.getColumnIndex(DBHelper.SUNDAY);
        int col4 = c.getColumnIndex(DBHelper.MONDAY);
        int col5 = c.getColumnIndex(DBHelper.TUESDAY);
        int col6 = c.getColumnIndex(DBHelper.WEDNESDAY);
        int col7 = c.getColumnIndex(DBHelper.THURSDAY);
        int col8 = c.getColumnIndex(DBHelper.FRIDAY);
        int col9 = c.getColumnIndex(DBHelper.SATURDAY);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);

            String[] schedulesPerDay = new String[] {s3, s4, s5, s6, s7, s8, s9};
            String[] arrDayNames = new String[] {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
            Lesson dayLssn;
            String[] hours;
            String[] splittedLesson;

            if (s1.equals(userID) && s2.equals(userPass)){
                for (int i=0; i<7; i++){
                    lessonsOfTheDayArrList.clear();
                    dayLssn = new Lesson(arrDayNames[i],"","","","", "", "", "");
                    lessonsOfTheDayArrList.add(dayLssn);
                    hours = schedulesPerDay[i].split("@"); //
                    for (int j=0; j<hours.length; j++){
                        if (hours[j].length() > 5 && !hours[j].equals("No lessons planned for this day") && !hours[j].equals("No free hours planned for this day")){
                            splittedLesson = hours[j].split("_");
                            lssn = new Lesson(splittedLesson[0], splittedLesson[1], splittedLesson[2], splittedLesson[3], splittedLesson[4], splittedLesson[5], splittedLesson[6], splittedLesson[7]);
                        }
                        else{
                            lssn = new Lesson(hours[j], "", "","","", "", "", "");
                        }
                        lessonsOfTheDayArrList.add(lssn);
                    }
                    for (int k=0; k<lessonsOfTheDayArrList.size(); k++){
                        allLessonsArrList.add(lessonsOfTheDayArrList.get(k));
                    }
                }
            }
            c.moveToNext();
        }
        sqdb.close();

        adapterLessons = new LessonAdapter(this, R.layout.custom_list_lessons, this.allLessonsArrList);
        lvSchedule.setAdapter(adapterLessons);
    }
}