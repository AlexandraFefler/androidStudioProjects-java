package com.example.eduprivate;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;

public class NotifService extends Service {
    /**
     * @author Alexandra Fefler
     * This class creates notification service
     */

    public NotifService() {
    }

    /**
     * Binds
     * @param intent
     * @return
     */
    @Override
    public IBinder onBind(Intent intent) {
        throw new UnsupportedOperationException("Not yet implemented");
    }

    /**
     * Creates and starts notifications process
     */
    @Override
    public void onCreate() {
        super.onCreate();
        String notifTitle = "No WiFi connection";
        String notifText = "Check your connection";
        NotificationCompat.Builder nBuilder = new NotificationCompat.Builder(this.getApplicationContext(), "notify_001");
        Intent ii = new Intent(this.getApplicationContext(), NotifService.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, ii, 0);

        nBuilder.setContentIntent(pendingIntent);
        nBuilder.setSmallIcon(R.drawable.iconimportant);
        nBuilder.setContentTitle(notifTitle);
        nBuilder.setContentText(notifText);
        nBuilder.setPriority(Notification.PRIORITY_MAX);

        NotificationManager nNotificationManager;
        nNotificationManager = (NotificationManager) this.getSystemService(Context.NOTIFICATION_SERVICE);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O){
            String channelID = "Your_channel_id";
            NotificationChannel channel = new NotificationChannel(channelID, "Channel human readable title", NotificationManager.IMPORTANCE_HIGH);
            nNotificationManager.createNotificationChannel(channel);
            nBuilder.setChannelId(channelID);
        }
        nNotificationManager.notify(0, nBuilder.build());
        stopSelf();
    }
}