package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import android.os.Handler;
import java.util.logging.LogRecord;

public class NotificationsPanel extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows panel of notifications
     */
    ListView lvNotifs;
    NotifAdapter adapterNotifs;
    ArrayList<Notification> notifsAL;
    Notification notif;

    String userID;
    String userPass;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    Handler handler = new Handler();

    Runnable refresh = new Runnable() {
        @Override
        public void run() {
            notifsAL.clear();
            showNotifs();
            handler.postDelayed(this, 1000);
        }
    };
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }
    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();


        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications_panel);

        Intent take = getIntent();
        userID = take.getStringExtra("ID");
        userPass = take.getStringExtra("Pass");

        lvNotifs = findViewById(R.id.lvNotifsPanel);
        notifsAL = new ArrayList<>();


        my_db = new DBHelper(this);
        showNotifs();

        handler.postDelayed(refresh, 1000); // does the refresh but also scrolls lv up so it doesn't let the user stay and read a notif if it's not on top. Can be ignored if I show a short enough lv ;)

        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }

    /**
     * Shows list of notifications on list view
     */
    private void showNotifs() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_NOTIFICATIONS, null, null, null, null, null, null);


        int col1 = c.getColumnIndex(DBHelper.IDRECEIVER);
        int col2 = c.getColumnIndex(DBHelper.PASSRECEIVER);
        int col3 = c.getColumnIndex(DBHelper.NOTIFICATIONTEXT);
        int col4 = c.getColumnIndex(DBHelper.LESSONDAY);
        int col5 = c.getColumnIndex(DBHelper.LESSONHOUR);
        int col6 = c.getColumnIndex(DBHelper.LESSONSUBJECT);
        int col7 = c.getColumnIndex(DBHelper.OTHERID);
        int col8 = c.getColumnIndex(DBHelper.OTHERPASS);
        int col9 = c.getColumnIndex(DBHelper.NOTIFICATIONTYPE);
        int col10 = c.getColumnIndex(DBHelper.ISACTIVE);


        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);

            boolean isActiveBool = s10.equals("true");

            if (s1.equals(userID) && s2.equals(userPass)){
                notif = new Notification(s1, s2, s3, s4, s5, s6, s7, s8, s9, isActiveBool);
                notifsAL.add(notif);
            }



            c.moveToNext();
        }
        sqdb.close();

        Collections.reverse(notifsAL);
        adapterNotifs = new NotifAdapter(this, R.layout.custom_list_notifications, this.notifsAL);
        lvNotifs.setAdapter(adapterNotifs);
    }

}