package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class UsersList extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows lists of all users and all teachers
     */
    ListView lvAllUsers;
    ArrayAdapter<User> adapterAllUsers;
    ArrayList<User> all_users;
    User user;

    ListView lvAllTeachers;
    ArrayAdapter<Teacher> adapterAllTeachers;
    ArrayList<Teacher> all_teachers;
    Teacher teacher;

    SQLiteDatabase sqdb;
    DBHelper my_db;
    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_users_list);

        lvAllUsers = findViewById(R.id.lvAllUsers);
        lvAllTeachers = findViewById(R.id.lvTeachers);

        all_users = new ArrayList<>();
        all_teachers = new ArrayList<>();

        my_db = new DBHelper(this);
        showAllUsers();
        showAllTeachers();
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        menu.add(0,1,0,"Show notifs and schedules");
        return true;
    }
    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID==1) {
            Intent goUsersList = new Intent(this, NotifsAndSchedulesLists.class);
            startActivity(goUsersList);
        }

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Shows list of teachers on list view
     */
    private void showAllTeachers() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);


        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);
        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);
            String s10 = c.getString(col10);
            String s11 = c.getString(col11);
            String s12 = c.getString(col12);

            boolean isTeacher = false;
            if (s8.equals("true")){
                isTeacher = true;
            }

            int priceInt = 0;
            if (!s10.isEmpty()){
                priceInt = Integer.parseInt(s10);
            }

            teacher = new Teacher(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9, priceInt, s11, s12);
            all_teachers.add(teacher);

            c.moveToNext();
        }
        sqdb.close();

        adapterAllTeachers = new ArrayAdapter<Teacher>(this, android.R.layout.simple_list_item_1, all_teachers);
        lvAllTeachers.setAdapter(adapterAllTeachers);
    }

    /**
     * Shows list of users on list view
     */
    private void showAllUsers() {
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);

        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);

            boolean isTeacher = false;
            if (s7.equals("true")){
                isTeacher = true;
            }

            user = new User(s1, s2, s3, s4, s5, s6, s7, isTeacher, s9);
            all_users.add(user);

            c.moveToNext();
        }
        sqdb.close();

        adapterAllUsers = new ArrayAdapter<User>(this, android.R.layout.simple_list_item_1, all_users);
        lvAllUsers.setAdapter(adapterAllUsers);
    }
}