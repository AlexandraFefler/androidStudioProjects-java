package com.example.eduprivate;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class NotifAdapter extends ArrayAdapter {
    /**
     * @author Alexandra Fefler
     * This class adapts an ArrayList of Notifications into a List View
     */
    private Context context;
    private ArrayList<Notification> list;
    private int layout;

    String str = "";
    SQLiteDatabase sqdb2;
    DBHelper my_db2;

    String nameOfDay = "", hourOfLesson = "";
    Boolean hourTaken = false;

    /**
     * Creates NotifAdapter object
     * @param context
     * @param layout
     * @param list
     */
    public NotifAdapter(@NonNull Context context, int layout, @NonNull ArrayList<Notification> list) {
        super(context, layout, list);

        this.context=context;
        this.layout=layout;
        this.list=list;
    }

    /**
     * Adapts an ArrayList of Notifications into a List View
     * @param position
     * @param convertView
     * @param parent
     * @return
     */
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        LayoutInflater layoutInflater = ((AppCompatActivity)context).getLayoutInflater();

        View view = layoutInflater.inflate(layout,parent,false);

        Notification notif = this.list.get(position);

        TextView tvNotifText = view.findViewById(R.id.tvNotifText);
        Button btnAccept = view.findViewById(R.id.btnAccept);
        Button btnDecline = view.findViewById(R.id.btnDecline);

        btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                hourTaken = false;

                //change for teacher
                my_db2 = new DBHelper((AppCompatActivity)context);
                sqdb2 = my_db2.getWritableDatabase();

                //for teacher's schedule
                ContentValues cv4 = new ContentValues();
                nameOfDay = list.get(position).getLessonDay();
                hourOfLesson = list.get(position).getLessonHour();

                String scheduleForDay = getNewDaySchedule(list.get(position).getIdReceiver(), list.get(position).getPassReceiver(), list.get(position).getLessonDay(), list.get(position).getLessonHour(), list.get(position).getOtherId(), list.get(position).getOtherPass(), list.get(position).getLessonSubject());
                String lessonDay = list.get(position).getLessonDay();

                if (lessonDay.equals("Sunday")){
                    cv4.put(my_db2.SUNDAY, scheduleForDay);

                }
                if (lessonDay.equals("Monday")){
                    cv4.put(my_db2.MONDAY, scheduleForDay);

                }
                if (lessonDay.equals("Tuesday")){
                    cv4.put(my_db2.TUESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Wednesday")){
                    cv4.put(my_db2.WEDNESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Thursday")){
                    cv4.put(my_db2.THURSDAY, scheduleForDay);

                }
                if (lessonDay.equals("Friday")){
                    cv4.put(my_db2.FRIDAY, scheduleForDay);

                }
                if (lessonDay.equals("Saturday")){
                    cv4.put(my_db2.SATURDAY, scheduleForDay);

                }
                sqdb2.update(DBHelper.TABLE_SCHEDULES, cv4, DBHelper.IDOWNER+"=? AND "+DBHelper.PASSOWNER+"=?", new String[]{list.get(position).getIdReceiver(), list.get(position).getPassReceiver()});
                sqdb2.close();

                if (!hourTaken){
                    //insert a new notification for both persons about this lesson being accepted
                    SQLiteDatabase sqdb;
                    DBHelper my_db;
                    my_db = new DBHelper((AppCompatActivity)context);
                    sqdb = my_db.getWritableDatabase();

                    String[] splittedSubj = list.get(position).getLessonSubject().split("_");
                    str = "The "+splittedSubj[0]+" ("+splittedSubj[1]+" level) lesson on "+ list.get(position).getLessonDay() + ", at "+list.get(position).getLessonHour() + " is accepted";

                    ContentValues cv = new ContentValues();
                    cv.put(my_db.IDRECEIVER, list.get(position).getOtherId());
                    cv.put(my_db.PASSRECEIVER, list.get(position).getOtherPass());
                    cv.put(my_db.NOTIFICATIONTEXT, str);
                    cv.put(my_db.LESSONDAY, list.get(position).getLessonDay());
                    cv.put(my_db.LESSONHOUR, list.get(position).getLessonHour());
                    cv.put(my_db.LESSONSUBJECT, list.get(position).getLessonSubject());
                    cv.put(my_db.OTHERID, list.get(position).getIdReceiver());
                    cv.put(my_db.OTHERPASS, list.get(position).getPassReceiver());
                    cv.put(my_db.NOTIFICATIONTYPE, "cancelbutton");
                    cv.put(my_db.ISACTIVE, "true");

                    sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv);

                    ContentValues cv2 = new ContentValues();
                    cv2.put(my_db.IDRECEIVER, list.get(position).getIdReceiver());
                    cv2.put(my_db.PASSRECEIVER, list.get(position).getPassReceiver());
                    cv2.put(my_db.NOTIFICATIONTEXT, str);
                    cv2.put(my_db.LESSONDAY, list.get(position).getLessonDay());
                    cv2.put(my_db.LESSONHOUR, list.get(position).getLessonHour());
                    cv2.put(my_db.LESSONSUBJECT, list.get(position).getLessonSubject());
                    cv2.put(my_db.OTHERID, list.get(position).getOtherId());
                    cv2.put(my_db.OTHERPASS, list.get(position).getOtherPass());
                    cv2.put(my_db.NOTIFICATIONTYPE, "cancelbutton");
                    cv2.put(my_db.ISACTIVE, "true");

                    sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv2);

                    ContentValues cv3 = new ContentValues();
                    cv3.put(my_db.NOTIFICATIONTYPE, "textonly");

                    sqdb.update(DBHelper.TABLE_NOTIFICATIONS, cv3, DBHelper.IDRECEIVER+"=? AND "+DBHelper.PASSRECEIVER+"=? AND "+DBHelper.NOTIFICATIONTEXT+"=?", new String[]{list.get(position).getIdReceiver(), list.get(position).getPassReceiver(), list.get(position).getNotificationText()});
                    sqdb.close();

                }
            }
        });
        btnDecline.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //insert a new notification for both persons about this lesson being declined
                SQLiteDatabase sqdb;
                DBHelper my_db;
                my_db = new DBHelper((AppCompatActivity)context);
                sqdb = my_db.getWritableDatabase();

                String[] splittedSubj = list.get(position).getLessonSubject().split("_");
                str = "The "+splittedSubj[0]+" ("+splittedSubj[1]+" level) lesson on "+ list.get(position).getLessonDay() + ", at "+list.get(position).getLessonHour() + " is declined";

                ContentValues cv = new ContentValues();
                cv.put(my_db.IDRECEIVER, list.get(position).getOtherId());
                cv.put(my_db.PASSRECEIVER, list.get(position).getOtherPass());
                cv.put(my_db.NOTIFICATIONTEXT, str);
                cv.put(my_db.LESSONDAY, list.get(position).getLessonDay());
                cv.put(my_db.LESSONHOUR, list.get(position).getLessonHour());
                cv.put(my_db.LESSONSUBJECT, list.get(position).getLessonSubject());
                cv.put(my_db.OTHERID, list.get(position).getOtherId());
                cv.put(my_db.OTHERPASS, list.get(position).getOtherPass());
                cv.put(my_db.NOTIFICATIONTYPE, "textonly");
                cv.put(my_db.ISACTIVE, "true");

                sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv);

                ContentValues cv2 = new ContentValues();
                cv2.put(my_db.IDRECEIVER, list.get(position).getIdReceiver());
                cv2.put(my_db.PASSRECEIVER, list.get(position).getPassReceiver());
                cv2.put(my_db.NOTIFICATIONTEXT, str);
                cv2.put(my_db.LESSONDAY, list.get(position).getLessonDay());
                cv2.put(my_db.LESSONHOUR, list.get(position).getLessonHour());
                cv2.put(my_db.LESSONSUBJECT, list.get(position).getLessonSubject());
                cv2.put(my_db.OTHERID, list.get(position).getOtherId());
                cv2.put(my_db.OTHERPASS, list.get(position).getOtherPass());
                cv2.put(my_db.NOTIFICATIONTYPE, "textonly");
                cv2.put(my_db.ISACTIVE, "true");

                sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv2);

                ContentValues cv3 = new ContentValues();
                cv3.put(my_db.NOTIFICATIONTYPE, "textonly");

                sqdb.update(DBHelper.TABLE_NOTIFICATIONS, cv3, DBHelper.IDRECEIVER+"=? AND "+DBHelper.PASSRECEIVER+"=? AND "+DBHelper.NOTIFICATIONTEXT+"=?", new String[]{list.get(position).getIdReceiver(), list.get(position).getPassReceiver(), list.get(position).getNotificationText()});

                sqdb.close();
            }
        });

        tvNotifText.setText(notif.getNotificationText());
        if(notif.getNotificationType().equals("textonly")){
            btnAccept.setVisibility(View.INVISIBLE);
            btnDecline.setVisibility(View.INVISIBLE);
            btnAccept.setClickable(false);
            btnDecline.setClickable(false);
        }
        if(notif.getNotificationType().equals("acceptdeclinebuttons")){
            btnAccept.setVisibility(View.VISIBLE);
            btnDecline.setVisibility(View.VISIBLE);
            btnAccept.setClickable(true);
            btnDecline.setClickable(true);
        }
        if(notif.getNotificationType().equals("cancelbutton")){
            btnAccept.setVisibility(View.INVISIBLE);
            btnDecline.setVisibility(View.INVISIBLE);
            btnAccept.setClickable(false);
            btnDecline.setClickable(false);
        }

        return view;
    }

    /**
     * Creates new schedule for day (with a particular lesson added)
     * @param usersID
     * @param usersPass
     * @param nameday
     * @param namehour
     * @return
     */
    private String getNewDaySchedule(String usersID, String usersPass, String nameday, String namehour, String studentId, String studentPass, String lessonSubj) {
        String strHours = "";
        SQLiteDatabase sqdb;
        DBHelper my_db;
        my_db = new DBHelper((AppCompatActivity)context);
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_SCHEDULES, null, null, null, null, null, null);

        int col1 = c.getColumnIndex(DBHelper.IDOWNER);
        int col2 = c.getColumnIndex(DBHelper.PASSOWNER);
        int col3 = c.getColumnIndex(DBHelper.SUNDAY);
        int col4 = c.getColumnIndex(DBHelper.MONDAY);
        int col5 = c.getColumnIndex(DBHelper.TUESDAY);
        int col6 = c.getColumnIndex(DBHelper.WEDNESDAY);
        int col7 = c.getColumnIndex(DBHelper.THURSDAY);
        int col8 = c.getColumnIndex(DBHelper.FRIDAY);
        int col9 = c.getColumnIndex(DBHelper.SATURDAY);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);

            String[] schedulesPerDay = new String[] {s3, s4, s5, s6, s7, s8, s9};
            String[] arrDayNames = new String[] {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
            String[] hours;
            String[] chkdhr;

            if (s1.equals(usersID) && s2.equals(usersPass)){
                for (int i=0; i<7; i++){
                    if (i == Arrays.asList(arrDayNames).indexOf(nameday)){
                        hours = schedulesPerDay[i].split("@");
                        for (int j=0; j<hours.length; j++){
                            chkdhr = hours[j].split("_");
                            if (chkdhr.length > 1) {//if one element - it's an empty hour. If not - it's a lesson
                                Toast.makeText(context, "There is a lesson planned for this hour", Toast.LENGTH_SHORT).show();
                                hourTaken = true;
                                return schedulesPerDay[i]; //return the original schedule for currently checked day (on i posistion)
                            }
                            if (chkdhr[0].equals(namehour)){ //if found the hour to be searched
                                String[] splittedLessn = lessonSubj.split("_");
                                hours[j] = namehour+"_"+splittedLessn[0]+"_"+splittedLessn[1]+"_"+studentId+"_"+studentPass+"_"+usersID+"_"+usersPass+"_"+nameday;
                            }
                            strHours += hours[j]+"@";//add the final hour string to the string of hours for the searched day
                        }
                    }
                }
            }
            c.moveToNext();
        }
        sqdb.close();
        return strHours;
    }

}
