package com.example.eduprivate;

import static org.xmlpull.v1.XmlPullParser.TYPES;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.provider.MediaStore;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;

public class LessonAdapter extends ArrayAdapter {
    /**
     * @author Alexandra Fefler
     * This class adapts an ArrayList of Lessons into a List View
     */
    private Context context;
    private ArrayList<Lesson> list;
    private int layout;

    SQLiteDatabase sqdb;
    DBHelper my_db;
    SQLiteDatabase sqdb2;
    DBHelper my_db2;

    String str = "";
    String nameOfDay = "";
    String hourOfLesson = "";
    Lesson lesson;

    String studentInfo = "";
    String teacherInfo = "";

    /**
     * Creates LessonAdapter object
     * @param context
     * @param layout
     * @param list
     */
    public LessonAdapter(@NonNull Context context, int layout, @NonNull ArrayList<Lesson> list) {
        super(context, layout, list);

        this.context=context;
        this.layout=layout;
        this.list=list;
    }

    /**
     * Adapts an ArrayList of Lessons into a List View
     * @param position
     * @param convertView
     * @param parent
     * @return
     */
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent){
        LayoutInflater layoutInflater = ((AppCompatActivity)context).getLayoutInflater();

        View view = layoutInflater.inflate(layout,parent,false);

        TextView tvStartHour = view.findViewById(R.id.tvStartLessonHour);
        TextView tvSubject = view.findViewById(R.id.tvLessonSubject);
        TextView tvInfo = view.findViewById(R.id.tvInfoL);
        Button btnFinishLesson = view.findViewById(R.id.btnFinishLesson);
        Button btnCancelLesson = view.findViewById(R.id.btnCancelLesson);

        btnFinishLesson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Lesson lssn = list.get(position);
                nameOfDay = lssn.getDay();
                hourOfLesson = lssn.getStartHour();

                //insert a new notification for the other person about lesson on lesson_info was cancelled
                my_db = new DBHelper((AppCompatActivity)context);
                sqdb = my_db.getWritableDatabase();

                str = "The "+lssn.getSubjectName()+" ("+lssn.getSubjectLevel()+" level) lesson on "+ list.get(position).getDay() + ", at "+list.get(position).getStartHour() + " is finished";

                ContentValues cv = new ContentValues();
                cv.put(my_db.IDRECEIVER, lssn.getStudentID());
                cv.put(my_db.PASSRECEIVER, lssn.getStudentPass());
                cv.put(my_db.NOTIFICATIONTEXT, str);
                cv.put(my_db.LESSONDAY, lssn.getDay());
                cv.put(my_db.LESSONHOUR, lssn.getStartHour());
                cv.put(my_db.LESSONSUBJECT, lssn.getSubjectName()+"_"+lssn.getSubjectLevel());
                cv.put(my_db.OTHERID, lssn.getTeacherID());
                cv.put(my_db.OTHERPASS, lssn.getTeacherPass());
                cv.put(my_db.NOTIFICATIONTYPE, "textonly");
                cv.put(my_db.ISACTIVE, "true");

                sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv);

                ContentValues cv2 = new ContentValues();
                cv2.put(my_db.IDRECEIVER, lssn.getTeacherID());
                cv2.put(my_db.PASSRECEIVER, lssn.getTeacherPass());
                cv2.put(my_db.NOTIFICATIONTEXT, str);
                cv2.put(my_db.LESSONDAY, lssn.getDay());
                cv2.put(my_db.LESSONHOUR, lssn.getStartHour());
                cv2.put(my_db.LESSONSUBJECT, lssn.getSubjectName()+"_"+lssn.getSubjectLevel());
                cv2.put(my_db.OTHERID, lssn.getStudentID());
                cv2.put(my_db.OTHERPASS, lssn.getStudentPass());
                cv2.put(my_db.NOTIFICATIONTYPE, "textonly");
                cv2.put(my_db.ISACTIVE, "true");

                sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv2);

                sqdb.close();

                my_db2 = new DBHelper((AppCompatActivity)context);
                sqdb2 = my_db2.getWritableDatabase();

                //for teacher's schedule
                ContentValues cv3 = new ContentValues();

                String scheduleForDay = getNewDaySchedule(lssn.getTeacherID(), lssn.getTeacherPass(), nameOfDay, hourOfLesson);
                String lessonDay = lssn.getDay();

                if (lessonDay.equals("Sunday")){
                    cv3.put(my_db2.SUNDAY, scheduleForDay);

                }
                if (lessonDay.equals("Monday")){
                    cv3.put(my_db2.MONDAY, scheduleForDay);

                }
                if (lessonDay.equals("Tuesday")){
                    cv3.put(my_db2.TUESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Wednesday")){
                    cv3.put(my_db2.WEDNESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Thursday")){
                    cv3.put(my_db2.THURSDAY, scheduleForDay);

                }
                if (lessonDay.equals("Friday")){
                    cv3.put(my_db2.FRIDAY, scheduleForDay);

                }
                if (lessonDay.equals("Saturday")){
                    cv3.put(my_db2.SATURDAY, scheduleForDay);

                }
                sqdb2.update(DBHelper.TABLE_SCHEDULES, cv3, DBHelper.IDOWNER+"=? AND "+DBHelper.PASSOWNER+"=?", new String[]{lssn.getTeacherID(), lssn.getTeacherPass()});

                //for student's schedule
                ContentValues cv4 = new ContentValues();
                nameOfDay = lssn.getDay();
                hourOfLesson = lssn.getStartHour();

                if (lessonDay.equals("Sunday")){
                    cv4.put(my_db2.SUNDAY, scheduleForDay);

                }
                if (lessonDay.equals("Monday")){
                    cv4.put(my_db2.MONDAY, scheduleForDay);

                }
                if (lessonDay.equals("Tuesday")){
                    cv4.put(my_db2.TUESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Wednesday")){
                    cv4.put(my_db2.WEDNESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Thursday")){
                    cv4.put(my_db2.THURSDAY, scheduleForDay);

                }
                if (lessonDay.equals("Friday")){
                    cv4.put(my_db2.FRIDAY, scheduleForDay);

                }
                if (lessonDay.equals("Saturday")){
                    cv4.put(my_db2.SATURDAY, scheduleForDay);

                }
                sqdb2.update(DBHelper.TABLE_SCHEDULES, cv4, DBHelper.IDOWNER+"=? AND "+DBHelper.PASSOWNER+"=?", new String[]{lssn.getStudentID(), lssn.getStudentPass()});

                sqdb2.close();
            }
        });

        btnCancelLesson.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Lesson lssn = list.get(position);
                nameOfDay = lssn.getDay();
                hourOfLesson = lssn.getStartHour();

                //insert a new notification for the other person about lesson on lesson_info was cancelled
                my_db = new DBHelper((AppCompatActivity)context);
                sqdb = my_db.getWritableDatabase();

                str = "The "+lssn.getSubjectName()+" ("+lssn.getSubjectLevel()+" level) lesson on "+ list.get(position).getDay() + ", at "+list.get(position).getStartHour() + " is cancelled";

                ContentValues cv = new ContentValues();
                cv.put(my_db.IDRECEIVER, lssn.getStudentID());
                cv.put(my_db.PASSRECEIVER, lssn.getStudentPass());
                cv.put(my_db.NOTIFICATIONTEXT, str);
                cv.put(my_db.LESSONDAY, lssn.getDay());
                cv.put(my_db.LESSONHOUR, lssn.getStartHour());
                cv.put(my_db.LESSONSUBJECT, lssn.getSubjectName()+"_"+lssn.getSubjectLevel());
                cv.put(my_db.OTHERID, lssn.getTeacherID());
                cv.put(my_db.OTHERPASS, lssn.getTeacherPass());
                cv.put(my_db.NOTIFICATIONTYPE, "textonly");
                cv.put(my_db.ISACTIVE, "true");

                sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv);

                ContentValues cv2 = new ContentValues();
                cv2.put(my_db.IDRECEIVER, lssn.getTeacherID());
                cv2.put(my_db.PASSRECEIVER, lssn.getTeacherPass());
                cv2.put(my_db.NOTIFICATIONTEXT, str);
                cv2.put(my_db.LESSONDAY, lssn.getDay());
                cv2.put(my_db.LESSONHOUR, lssn.getStartHour());
                cv2.put(my_db.LESSONSUBJECT, lssn.getSubjectName()+"_"+lssn.getSubjectLevel());
                cv2.put(my_db.OTHERID, lssn.getStudentID());
                cv2.put(my_db.OTHERPASS, lssn.getStudentPass());
                cv2.put(my_db.NOTIFICATIONTYPE, "textonly");
                cv2.put(my_db.ISACTIVE, "true");

                sqdb.insert(my_db.TABLE_NOTIFICATIONS, null, cv2);

                sqdb.close();

                my_db2 = new DBHelper((AppCompatActivity)context);
                sqdb2 = my_db2.getWritableDatabase();

                //for teacher's schedule
                ContentValues cv3 = new ContentValues();

                String scheduleForDay = getNewDaySchedule(lssn.getTeacherID(), lssn.getTeacherPass(), nameOfDay, hourOfLesson);
                String lessonDay = lssn.getDay();

                if (lessonDay.equals("Sunday")){
                    cv3.put(my_db2.SUNDAY, scheduleForDay);

                }
                if (lessonDay.equals("Monday")){
                    cv3.put(my_db2.MONDAY, scheduleForDay);

                }
                if (lessonDay.equals("Tuesday")){
                    cv3.put(my_db2.TUESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Wednesday")){
                    cv3.put(my_db2.WEDNESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Thursday")){
                    cv3.put(my_db2.THURSDAY, scheduleForDay);

                }
                if (lessonDay.equals("Friday")){
                    cv3.put(my_db2.FRIDAY, scheduleForDay);

                }
                if (lessonDay.equals("Saturday")){
                    cv3.put(my_db2.SATURDAY, scheduleForDay);

                }
                sqdb2.update(DBHelper.TABLE_SCHEDULES, cv3, DBHelper.IDOWNER+"=? AND "+DBHelper.PASSOWNER+"=?", new String[]{lssn.getTeacherID(), lssn.getTeacherPass()});

                //for student's schedule
                ContentValues cv4 = new ContentValues();
                nameOfDay = lssn.getDay();
                hourOfLesson = lssn.getStartHour();

                if (lessonDay.equals("Sunday")){
                    cv4.put(my_db2.SUNDAY, scheduleForDay);

                }
                if (lessonDay.equals("Monday")){
                    cv4.put(my_db2.MONDAY, scheduleForDay);

                }
                if (lessonDay.equals("Tuesday")){
                    cv4.put(my_db2.TUESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Wednesday")){
                    cv4.put(my_db2.WEDNESDAY, scheduleForDay);

                }
                if (lessonDay.equals("Thursday")){
                    cv4.put(my_db2.THURSDAY, scheduleForDay);

                }
                if (lessonDay.equals("Friday")){
                    cv4.put(my_db2.FRIDAY, scheduleForDay);

                }
                if (lessonDay.equals("Saturday")){
                    cv4.put(my_db2.SATURDAY, scheduleForDay);

                }
                sqdb2.update(DBHelper.TABLE_SCHEDULES, cv4, DBHelper.IDOWNER+"=? AND "+DBHelper.PASSOWNER+"=?", new String[]{lssn.getStudentID(), lssn.getStudentPass()});

                sqdb2.close();
            }
        });

        Lesson lssn = list.get(position);
        nameOfDay = lssn.getDay();
        hourOfLesson = lssn.getStartHour();

        tvStartHour.setText(lssn.getStartHour());
        if (lssn.getSubjectName().equals("")){
            if (!lssn.getStartHour().endsWith(":00")){
                view.setBackgroundColor(Color.parseColor("#07292B"));
            }
            else{
                view.setBackgroundColor(Color.parseColor("#006064"));
            }
            tvSubject.setText("");
            btnCancelLesson.setVisibility(View.INVISIBLE);
            btnFinishLesson.setVisibility(View.INVISIBLE);
            btnCancelLesson.setClickable(false);
            btnFinishLesson.setClickable(false);
        }
        else{
            String tel = "", email = "";
            boolean flag = false;
            SQLiteDatabase sqdb;
            DBHelper my_db;
            my_db = new DBHelper((AppCompatActivity)context);
            sqdb = my_db.getWritableDatabase();

            Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
            int col1 = c.getColumnIndex(DBHelper.ID);
            int col2 = c.getColumnIndex(DBHelper.NAME);
            int col3 = c.getColumnIndex(DBHelper.PASSWORD);
            int col4 = c.getColumnIndex(DBHelper.PHONE);
            int col5 = c.getColumnIndex(DBHelper.EMAIL);

            c.moveToFirst();
            while (!c.isAfterLast() && !flag) {
                String s1 = c.getString(col1);
                String s2 = c.getString(col2);
                String s3 = c.getString(col3);
                String s4 = c.getString(col4);
                String s5 = c.getString(col5);
                if (lssn.getStudentID().equals(s1) && lssn.getStudentPass().equals(s3)) {
                    flag = true;
                    if (s4.isEmpty()){
                        tel = " - ";
                    }
                    else{
                        tel = s4;
                    }
                    if (s5.isEmpty()){
                        email = " - ";
                    }
                    else{
                        email = s5;
                    }
                    studentInfo = "Student ("+s2+"): \nTel.: "+tel+"\nEmail: "+email;
                    tel = " - ";
                    email = " - ";
                }
                c.moveToNext();
            }

            flag = false;
            c.moveToFirst();
            while (!c.isAfterLast() && !flag) {
                String s1 = c.getString(col1);
                String s2 = c.getString(col2);
                String s3 = c.getString(col3);
                String s4 = c.getString(col4);
                String s5 = c.getString(col5);

                if (lssn.getTeacherID().equals(s1) && lssn.getTeacherPass().equals(s3)) {
                    flag = true;
                    if (s4.isEmpty()){
                        tel = " - ";
                    }
                    else{
                        tel = s4;
                    }
                    if (s5.isEmpty()){
                        email = " - ";
                    }
                    else{
                        email = s5;
                    }
                    teacherInfo = "Teacher ("+s2+"): \nTel.: "+tel+"\nEmail: "+email;

                }
                c.moveToNext();
            }

            sqdb.close();

            tvInfo.setText(teacherInfo + "\n"+studentInfo);
            tvSubject.setText(lssn.getSubjectName()+" ("+lssn.getSubjectLevel()+")");
            btnCancelLesson.setVisibility(View.VISIBLE);
            btnFinishLesson.setVisibility(View.VISIBLE);
            btnCancelLesson.setClickable(true);
            btnFinishLesson.setClickable(true);
        }

        return view;
    }


    /**
     * Creates new schedule for day (with a particular lesson removed)
     * @param usersID
     * @param usersPass
     * @param nameday
     * @param namehour
     * @return
     */
    private String getNewDaySchedule(String usersID, String usersPass, String nameday, String namehour) {
        String strHours = "";
        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_SCHEDULES, null, null, null, null, null, null);

        int col1 = c.getColumnIndex(DBHelper.IDOWNER);
        int col2 = c.getColumnIndex(DBHelper.PASSOWNER);
        int col3 = c.getColumnIndex(DBHelper.SUNDAY);
        int col4 = c.getColumnIndex(DBHelper.MONDAY);
        int col5 = c.getColumnIndex(DBHelper.TUESDAY);
        int col6 = c.getColumnIndex(DBHelper.WEDNESDAY);
        int col7 = c.getColumnIndex(DBHelper.THURSDAY);
        int col8 = c.getColumnIndex(DBHelper.FRIDAY);
        int col9 = c.getColumnIndex(DBHelper.SATURDAY);

        c.moveToFirst();
        while (!c.isAfterLast()){
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            String s6 = c.getString(col6);
            String s7 = c.getString(col7);
            String s8 = c.getString(col8);
            String s9 = c.getString(col9);

            String[] schedulesPerDay = new String[] {s3, s4, s5, s6, s7, s8, s9};
            String[] arrDayNames = new String[] {"Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"};
            String[] hours;
            String[] chkdhr;

            if (s1.equals(usersID) && s2.equals(usersPass)){
                for (int i=0; i<7; i++){
                    if (i == Arrays.asList(arrDayNames).indexOf(nameday)){
                        hours = schedulesPerDay[i].split("@"); //
                        for (int j=0; j<hours.length; j++){
                            chkdhr = hours[j].split("_");
                            if (chkdhr[0].equals(namehour)){ //if found the hour to be searched
                                hours[j] = namehour; //change it into just the hour ("hh:00")
                            }
                            strHours += hours[j]+"@";//add the final hour string to the string of hours for the searched day
                        }
                    }

                }
            }

            c.moveToNext();
        }
        sqdb.close();
        return strHours;
    }

}
