package com.example.eduprivate;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.widget.ImageView;

import com.bumptech.glide.Glide;

import java.security.PublicKey;

public class Loading extends AppCompatActivity {
    /**
     * @author Alexandra Fefler
     * This activity shows loading animation
     */
    ImageView iv;
    Handler handler;

    /**
     * Starts activity again
     * initializes properties of the class
     * shows all graphics objects
     */
    @Override
    protected void onResume() {
        super.onResume();

        handler.postDelayed(new Runnable() {

            @Override
            public void run() {
                Intent intent = new Intent(Loading.this, MainActivity.class);
                Loading.this.startActivity(intent);
            }

        }, 1500);
    }

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_loading);

        iv = findViewById(R.id.ivLoading);
        Glide.with(this).load(R.drawable.loading).into(iv);

        handler= new Handler();
    }
}