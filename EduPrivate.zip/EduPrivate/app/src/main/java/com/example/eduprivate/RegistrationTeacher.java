package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class RegistrationTeacher extends AppCompatActivity implements AdapterView.OnItemSelectedListener{
    /**
     * @author Alexandra Fefler
     * This activity allows to register as a teacher
     */
    ArrayList infoBasic;
    EditText etExtraComments, etPrice, etExperience, etSubjectName, etOtherLevel;
    Button btnInsert, btnAddSubject;
    TextView tvTitle;


    SQLiteDatabase sqdb;
    DBHelper my_db;

    Spinner spLevels;
    ArrayList<String> allLevels;
    ArrayAdapter<String> adapterLevels;
    String studyLevel = "";

    String allSubjects = ""; //will be saved in TEACHINGSUBJECTS in the database later

    int regCounter = 0;
    boolean isSettings = false;
    String oldTeacherID = "", oldTeacherPass = "";

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_teacher);

        etExtraComments = findViewById(R.id.etExtraCommentsTeacher);
        etPrice = findViewById(R.id.etPrice);
        etExperience = findViewById(R.id.etExperience);
        etSubjectName = findViewById(R.id.etSubjectName);
        etOtherLevel = findViewById(R.id.etOtherLevel);
        btnInsert = findViewById(R.id.btnRegisterTeacher);
        btnAddSubject = findViewById(R.id.btnAddSubj);
        spLevels = findViewById(R.id.spLevels);
        tvTitle = findViewById(R.id.tvTitle);

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        allLevels = new ArrayList<>();
        allLevels.add("Choose level");
        //adding default levels by grades (from 1st to 12th grade)
        for (int i=1; i<=12; i++){
            allLevels.add(i+" grade");
        }
        allLevels.add("Other");

        adapterLevels = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, allLevels);
        spLevels.setAdapter(adapterLevels);
        spLevels.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(allLevels.get(position).equals("Other")){
                    etOtherLevel.setVisibility(View.VISIBLE);
                }
                else{
                    if (allLevels.get(position).equals("Choose level")){
                        studyLevel = "";
                    }
                    else{
                        etOtherLevel.setText("");
                        etOtherLevel.setVisibility(View.INVISIBLE);
                        studyLevel = allLevels.get(position);
                    }
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                studyLevel = "";
            }
        });

        btnAddSubject.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (checkSubject()){
                    allSubjects += etSubjectName.getText().toString() + "_" + studyLevel + "@"; //subject = name_level, separated by "@"
                }
                else{
                    AlertDialog.Builder adb;
                    adb = new AlertDialog.Builder(RegistrationTeacher.this);
                    adb.setTitle("Something's wrong");
                    adb.setMessage("There's something wrong in the subject. A subject should have a name and a level, without any special letters (@, $, &, etc.)" + "\n - - to clear  press 'Cancel' - - ");
                    adb.setIcon(R.drawable.iconimportant);
                    adb.setCancelable(false);
                    adb.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            etOtherLevel.setText("");
                        }
                    });
                    AlertDialog adbb = adb.create();
                    adbb.show();
                }
                etOtherLevel.setText("");
            }
        });

        Intent take = getIntent();
        infoBasic = (ArrayList<String>)take.getStringArrayListExtra("info");
        isSettings = take.getBooleanExtra("isSettings", false); //gets information about the mode - is it settings or registration
        oldTeacherID = take.getStringExtra("oldUserID");
        oldTeacherPass = take.getStringExtra("oldUserPass");

        if(isSettings){
            showExistingTeacherData();
            etSubjectName.setVisibility(View.INVISIBLE);
            etOtherLevel.setVisibility(View.INVISIBLE);
            btnAddSubject.setVisibility(View.INVISIBLE);
            spLevels.setVisibility(View.INVISIBLE);
            btnInsert.setText("Save changes");
            btnInsert.setTextSize(27);
            tvTitle.setText("Change your personal info");
            tvTitle.setTextSize(25);
        }

        btnInsert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (isSettings){
                    UpdateData();
                }
                else{
                    if (regCounter == 0){
                        insertData();
                        regCounter++;
                    }
                    else{
                        Toast.makeText(RegistrationTeacher.this, "You can't register twice", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    /**
     * If activity is in settings mode, show logged in user data
     */
    private void showExistingTeacherData() {
        boolean flag = false;

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col4 = c.getColumnIndex(DBHelper.PRICE);
        int col5 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            String s4 = c.getString(col4);
            String s5 = c.getString(col5);
            if (oldTeacherID.equals(s1) && oldTeacherPass.equals(s2)) {
                flag = true;
                etExperience.setText(s3);
                etPrice.setText(s4);
                etExtraComments.setText(s5);
            }
            c.moveToNext();
        }
        sqdb.close();
    }
    /**
     * If activity is in settings mode, update logged in user's wor in database
     */
    private void UpdateData() {
        //update data for existing line in DB
        String strExtraComments = etExtraComments.getText().toString();
        String strExperience = etExperience.getText().toString();
        String strPrice = etPrice.getText().toString();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(my_db.ID, infoBasic.get(0).toString());
        cv.put(my_db.NAME, infoBasic.get(1).toString());
        cv.put(my_db.PASSWORD, infoBasic.get(2).toString());
        cv.put(my_db.PHONE, infoBasic.get(3).toString());
        cv.put(my_db.EMAIL, infoBasic.get(4).toString());
        cv.put(my_db.ADDRESS, infoBasic.get(5).toString());
        cv.put(my_db.PIC, infoBasic.get(6).toString());
        cv.put(my_db.ISTEACHER, "true"); //if it's in teacher registration activity, the user is a teacher
        cv.put(my_db.EXTRACOMMENTS, strExtraComments);

        sqdb.update(DBHelper.TABLE_ALL_USERS, cv, DBHelper.ID+"=? AND "+DBHelper.PASSWORD+"=?", new String[]{oldTeacherID, oldTeacherPass});

        ContentValues cv2 = new ContentValues();
        cv2.put(my_db.ID, infoBasic.get(0).toString());
        cv2.put(my_db.NAME, infoBasic.get(1).toString());
        cv2.put(my_db.PASSWORD, infoBasic.get(2).toString());
        cv2.put(my_db.PHONE, infoBasic.get(3).toString());
        cv2.put(my_db.EMAIL, infoBasic.get(4).toString());
        cv2.put(my_db.ADDRESS, infoBasic.get(5).toString());
        cv2.put(my_db.PIC, infoBasic.get(6).toString());
        cv2.put(my_db.ISTEACHER, "true"); //if it's in teacher registration activity, the user is a teacher
        cv2.put(my_db.EXTRACOMMENTS, strExtraComments);
        cv2.put(my_db.PRICE, strPrice);
        cv2.put(my_db.EXPERIENCE, strExperience);

        sqdb.update(DBHelper.TABLE_TEACHERS, cv2, DBHelper.ID+"=? AND "+DBHelper.PASSWORD+"=?", new String[]{oldTeacherID, oldTeacherPass});
        sqdb.close();

        Toast.makeText(this, "User updated in system", Toast.LENGTH_SHORT).show();
    }

    /**
     * Checks if subject is valid
     * A subject is name_level -> name has to be only letters, spaces allowed. A level is the same. they both can be just 1 letter, it's fine
     * @return
     */
    private boolean checkSubject() {
        String strSubjName = etSubjectName.getText().toString();
        if (!etOtherLevel.getText().toString().isEmpty()){
            studyLevel = etOtherLevel.getText().toString();
        }

        if (!strSubjName.isEmpty()){
            char[] chars1 = strSubjName.toCharArray();
            for (char c : chars1){
                if (!Character.isLetter(c) && !Character.isSpaceChar(c)){
                    return false;
                }
            }
        }
        else{
            return false;
        }

        if(!studyLevel.isEmpty()){
            char[] chars2 = studyLevel.toCharArray();
            for (char c : chars2){
                if (!Character.isLetter(c) && !Character.isSpaceChar(c) && !Character.isDigit(c)){
                    return false;
                }
            }
        }
        else{
            return false;
        }
        return true;
    }
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }
        return super.onOptionsItemSelected(item);
    }
    /**
     * Inserts user data into database
     */
    private void insertData() {
        String strExtraComments = etExtraComments.getText().toString();
        String strPrice = etPrice.getText().toString();
        String strExperience = etExperience.getText().toString();

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();

        ContentValues cv = new ContentValues();

        cv.put(my_db.ID, infoBasic.get(0).toString());
        cv.put(my_db.NAME, infoBasic.get(1).toString());
        cv.put(my_db.PASSWORD, infoBasic.get(2).toString());
        cv.put(my_db.PHONE, infoBasic.get(3).toString());
        cv.put(my_db.EMAIL, infoBasic.get(4).toString());
        cv.put(my_db.ADDRESS, infoBasic.get(5).toString());
        cv.put(my_db.PIC, infoBasic.get(6).toString());
        cv.put(my_db.ISTEACHER, "true"); //if it's in teacher registration activity, the user is not a teacher
        cv.put(my_db.EXTRACOMMENTS, strExtraComments);

        sqdb.insert(my_db.TABLE_ALL_USERS, null, cv);

        //adding teacher-only info into teachers-only table
        ContentValues cv2 = new ContentValues();

        cv2.put(my_db.ID, infoBasic.get(0).toString());
        cv2.put(my_db.NAME, infoBasic.get(1).toString());
        cv2.put(my_db.PASSWORD, infoBasic.get(2).toString());
        cv2.put(my_db.PHONE, infoBasic.get(3).toString());
        cv2.put(my_db.EMAIL, infoBasic.get(4).toString());
        cv2.put(my_db.ADDRESS, infoBasic.get(5).toString());
        cv2.put(my_db.PIC, infoBasic.get(6).toString());
        cv2.put(my_db.ISTEACHER, "true"); //if it's in teacher registration activity, the user is not a teacher
        cv2.put(my_db.EXTRACOMMENTS, strExtraComments);

        cv2.put(my_db.PRICE, strPrice);
        cv2.put(my_db.EXPERIENCE, strExperience);
        cv2.put(my_db.TEACHINGSUBJECTS, allSubjects);

        sqdb.insert(my_db.TABLE_TEACHERS, null, cv2);

        ContentValues cv3 = new ContentValues();
        cv3.put(my_db.IDOWNER, infoBasic.get(0).toString());
        cv3.put(my_db.PASSOWNER, infoBasic.get(2).toString());
        cv3.put(my_db.SUNDAY, "16:00@17:00@18:00@19:00@");
        cv3.put(my_db.MONDAY, "16:00@17:00@18:00@19:00@");
        cv3.put(my_db.TUESDAY, "16:00@17:00@18:00@19:00@");
        cv3.put(my_db.WEDNESDAY, "16:00@17:00@18:00@19:00@");
        cv3.put(my_db.THURSDAY, "16:00@17:00@18:00@19:00@");
        cv3.put(my_db.FRIDAY, "16:00@17:00@18:00@19:00@");
        cv3.put(my_db.SATURDAY, "16:00@17:00@18:00@19:00@");

        sqdb.insert(my_db.TABLE_SCHEDULES, null, cv3);

        sqdb.close();

        Toast.makeText(this, "Teacher and user registered in system", Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}