package com.example.eduprivate;

import android.os.Parcel;
import android.os.Parcelable;

public class User {
    /**
     * @author Alexandra Fefler
     * This class represents a lesson and it's properties
     */
    private String id; //key identifier
    private String name; // must not be empty, but not a key-identifier
    private String password; //also key-identifier
    private String phone; //can be empty
    private String email; //can be empty
    private String address; //can be empty
    private String pic; //can be empty
    private boolean isTeacher; //only can be "true"/"false"
    private String extraComments; //extra/specific details, can be empty

    /**
     * Creates a User object
     * @param id
     * @param name
     * @param password
     * @param phone
     * @param email
     * @param address
     * @param pic
     * @param isTeacher
     * @param extraComments
     */
    public User(String id, String name, String password, String phone, String email, String address, String pic, boolean isTeacher, String extraComments) {
        this.id = id;
        this.name = name;
        this.password = password;
        this.phone = phone;
        this.email = email;
        this.address = address;
        this.pic = pic;
        this.isTeacher = isTeacher;
        this.extraComments = extraComments;
    }

    /**
     * Getter for ID
     * @return ID
     */
    public String getID() {
        return id;
    }

    /**
     * Setter for ID
     * @param id ID
     */
    public void setID(String id) {
        this.id = id;
    }

    /**
     * Getter for name
     * @return name
     */
    public String getName() {
        return name;
    }

    /**
     * Setter for name
     * @param name name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Getter for password
     * @return password
     */
    public String getPassword() {
        return password;
    }

    /**
     * Setter for password
     * @param password password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Getter for phone number
     * @return phone number
     */
    public String getPhone() {
        return phone;
    }

    /**
     * Setter for phone number
     * @param phone phone number
     */
    public void setPhone(String phone) {
        this.phone = phone;
    }

    /**
     * Getter for email
     * @return email
     */
    public String getEmail() {
        return email;
    }

    /**
     * Setter for email
     * @param email email
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * Getter for address
     * @return address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Setter for address
     * @param address address
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * Getter for path to pic on internal storage
     * @return path to pic on internal storage
     */
    public String getPic() {
        return pic;
    }

    /**
     * Setter path to pic on internal storage
     * @param pic path to pic on internal storage
     */
    public void setPic(String pic) {
        this.pic = pic;
    }

    /**
     * Getter for extra comments
     * @return extra comments
     */
    public String getExtraComments() {
        return extraComments;
    }

    /**
     * Setter for extra comments
     * @param studyLevel extra comments
     */
    public void setExtraComments(String studyLevel) {
        this.extraComments = extraComments;
    }

    /**
     * Getter for isTeacher
     * @return true if the user is a teacher
     */
    public boolean getIsTeacher() {
        return isTeacher;
    }

    /**
     * Setter for isTeacher
     * @param isTeacher true if the user is a teacher
     */
    public void setIsTeacher(boolean isTeacher) {
        this.isTeacher = isTeacher;
    }

    /**
     * Creates string representation of User
     * @return string of User
     */
    @Override
    public String toString() {
        return "User:" +
                "\nID: "+ id +
                "\nname: "+ name +
                "\npassword: " + password +
                "\nphone: " + phone +
                "\nemail: " + email +
                "\naddress: " + address +
                "\npic: " + pic +
                "\nisTeacher: " + isTeacher +
                "\nextraComments: " + extraComments+"\n";
    }
}
