package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.res.TypedArrayUtils;

import android.content.ContentValues;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.Toast;

import java.sql.Time;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;

public class TeacherSettings extends AppCompatActivity implements AdapterView.OnItemClickListener , AdapterView.OnItemLongClickListener {
    /**
     * @author Alexandra Fefler
     * This activity allows teacher to edit teaching subjects
     */
    EditText etSubjName, etOtherSubjLvl;
    Button btnUpdSubj, btnAddNewSubj, btnReset;
    ListView lvTeachingSubjects;
    ArrayList<String> listArrTeachingSubjects;
    String subject = "";
    String oldTS = "";
    ArrayAdapter<String> adapterSubjs;

    Spinner spLevels;
    ArrayList<String> allLevels;
    ArrayAdapter<String> adapterLevels;
    String studyLevel = "";

    SQLiteDatabase sqdb;
    DBHelper my_db;

    String teacherID = "", teacherPass = "";
    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }

    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();

        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teacher_settings);

        Intent take = getIntent();
        teacherID = take.getStringExtra("teacherID");
        teacherPass = take.getStringExtra("teacherPass");

        etSubjName = findViewById(R.id.etSubjectName);
        etOtherSubjLvl = findViewById(R.id.etOtherLevel);
        lvTeachingSubjects = findViewById(R.id.lvTeachingSubjects);
        listArrTeachingSubjects = new ArrayList<String>();

        lvTeachingSubjects.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //split line's string into name and level
                String[] splittedSubject = listArrTeachingSubjects.get(position).split(" - ");
                //put the name into the etName
                etSubjName.setText(splittedSubject[0]);
                etSubjName.setHint(splittedSubject[0]);
                //set the selection of the spinner to the extracted lvl, if it's none from the options then choose "other", open etOtherLvl and pit the subjlvl into its text
                boolean idk = allLevels.contains(splittedSubject[1]);
                if (!allLevels.contains(splittedSubject[1])){ //in case no levels from list are the one in splittedSubject[1], it's in the "other" category
                    spLevels.setSelection(allLevels.size()-1); //set to the last option which is always "other"
                    etOtherSubjLvl.setVisibility(View.VISIBLE); //shows etOtherLevel
                    etOtherSubjLvl.setText(splittedSubject[1]);
                }
                else{
                    //figure out where splittetSubject[1] is on the list of allLevels to setSelection with this int for spLevels
                    for(int i=0; i<allLevels.size(); i++){
                        if(allLevels.get(i).equals(splittedSubject[1])){
                            spLevels.setSelection(i);
                        }
                    }
                    etOtherSubjLvl.setVisibility(View.INVISIBLE);
                    etOtherSubjLvl.setText("");
                }
                //save the line's string to find it in DB in the future (in btnUpd)
                oldTS = splittedSubject[0]+"_"+splittedSubject[1];
            }
        });

        lvTeachingSubjects.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                ////getting the ts from selected line in right form (name_lvl i mean)
                String[] splittedSubject = listArrTeachingSubjects.get(position).split(" - ");
                oldTS = splittedSubject[0]+"_"+splittedSubject[1];

                AlertDialog.Builder adb;
                adb=new AlertDialog.Builder(TeacherSettings.this);
                adb.setTitle("Delete subject");
                adb.setMessage(" Are you sure? ");
                adb.setIcon(R.drawable.iconimportant);
                adb.setCancelable(false);
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        listArrTeachingSubjects.remove(position);
                        //opening DB
                        my_db = new DBHelper(TeacherSettings.this);
                        sqdb = my_db.getWritableDatabase();

                        String teachingSubjectsString = "";
                        //getting this string out of DB:
                        boolean flag = false;
                        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
                        int col1 = c.getColumnIndex(DBHelper.ID);
                        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
                        int col3 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

                        c.moveToFirst();
                        while (!c.isAfterLast() && !flag) {
                            String s1 = c.getString(col1);
                            String s2 = c.getString(col2);
                            String s3 = c.getString(col3);
                            if (teacherID.equals(s1) && teacherPass.equals(s2)) {
                                teachingSubjectsString = s3;
                            }
                            c.moveToNext();
                        }

                        //changing the old ts to the new one
                        String[] splittedTS = teachingSubjectsString.split("@");
                        for (int i=0; i<splittedTS.length; i++){
                            if (splittedTS[i].equals(oldTS)){ //if equals the old ts
                                splittedTS[i] = ""; //change to empty str = delete from str
                            }
                        }

                        //saving the new ts's whole string:
                        teachingSubjectsString = "";
                        for (int j=0; j<splittedTS.length; j++){
                            if (!splittedTS[j].equals("")){ //if ts is empty, just ignore it - it was deleted
                                teachingSubjectsString += splittedTS[j]+"@";
                            }
                        }

                        ContentValues cv = new ContentValues();
                        cv.put(my_db.TEACHINGSUBJECTS, teachingSubjectsString);

                        sqdb.update(DBHelper.TABLE_TEACHERS, cv, DBHelper.ID+"=? AND "+DBHelper.PASSWORD+"=?", new String[]{teacherID, teacherPass});
                        sqdb.close();
                        showSubjects();

                        Toast.makeText(TeacherSettings.this, "Teaching subject has been deleted", Toast.LENGTH_SHORT).show();

                    }
                });

                adb.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });

                AlertDialog ad = adb.create();
                ad.show();

                return true;
            }
        });

        btnReset = findViewById(R.id.btnReset);
        btnReset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //empty et and spinner:
                etSubjName.setText("");
                etSubjName.setHint("Enter subject name");
                spLevels.setSelection(0);
                etOtherSubjLvl.setVisibility(View.INVISIBLE);
                etOtherSubjLvl.setText("");
                etOtherSubjLvl.setHint("Enter other subject level");
            }
        });

        btnUpdSubj = findViewById(R.id.btnUpdSubj);
        btnUpdSubj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //saving the new ts data:
                String newTS = "";
                if (checkSubject()){
                    newTS = etSubjName.getText().toString() + "_" + studyLevel; //subject = name_level

                    //opening DB
                    my_db = new DBHelper(TeacherSettings.this);
                    sqdb = my_db.getWritableDatabase();

                    String teachingSubjectsString = "";

                    //getting this string out of DB:
                    boolean flag = false;
                    Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
                    int col1 = c.getColumnIndex(DBHelper.ID);
                    int col2 = c.getColumnIndex(DBHelper.PASSWORD);
                    int col3 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

                    c.moveToFirst();
                    while (!c.isAfterLast() && !flag) {
                        String s1 = c.getString(col1);
                        String s2 = c.getString(col2);
                        String s3 = c.getString(col3);
                        if (teacherID.equals(s1) && teacherPass.equals(s2)) {
                            teachingSubjectsString = s3;
                        }
                        c.moveToNext();
                    }

                    //changing the old ts to the new one
                    String[] splittedTS = teachingSubjectsString.split("@");
                    for (int i=0; i<splittedTS.length; i++){
                        if (splittedTS[i].equals(oldTS)){ //if equals the old ts
                            splittedTS[i] = newTS; //change to new ts
                        }
                    }

                    //saving the new ts's whole string:
                    teachingSubjectsString = "";
                    for (int j=0; j<splittedTS.length; j++){
                        teachingSubjectsString += splittedTS[j]+"@";
                    }

                    ContentValues cv = new ContentValues();
                    cv.put(my_db.TEACHINGSUBJECTS, teachingSubjectsString);

                    sqdb.update(DBHelper.TABLE_TEACHERS, cv, DBHelper.ID+"=? AND "+DBHelper.PASSWORD+"=?", new String[]{teacherID, teacherPass});
                    sqdb.close();
                    showSubjects();

                    Toast.makeText(TeacherSettings.this, "Teaching subjects updated in system", Toast.LENGTH_SHORT).show();
                }
                else{
                    AlertDialog.Builder adb;
                    adb = new AlertDialog.Builder(TeacherSettings.this);
                    adb.setTitle("Something's wrong");
                    adb.setMessage("There's something wrong in the subject. A subject should have a name and a level, without any special letters (@, $, &, etc.)" + "\n - - to clear  press 'Cancel' - - ");
                    adb.setIcon(R.drawable.iconimportant);
                    adb.setCancelable(false);
                    adb.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            etOtherSubjLvl.setText("");
                        }
                    });
                    AlertDialog adbb = adb.create();
                    adbb.show();
                }
                etOtherSubjLvl.setText("");
            }
        });

        btnAddNewSubj = findViewById(R.id.btnNewSubj);
        btnAddNewSubj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //save the new ts:
                String newTS = "";
                if (checkSubject()){
                    newTS = etSubjName.getText().toString() + "_" + studyLevel; //subject = name_level

                    //opening DB
                    my_db = new DBHelper(TeacherSettings.this);
                    sqdb = my_db.getWritableDatabase();

                    String teachingSubjectsString = "";

                    //getting this string out of DB:
                    boolean flag = false;
                    Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
                    int col1 = c.getColumnIndex(DBHelper.ID);
                    int col2 = c.getColumnIndex(DBHelper.PASSWORD);
                    int col3 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

                    c.moveToFirst();
                    while (!c.isAfterLast() && !flag) {
                        String s1 = c.getString(col1);
                        String s2 = c.getString(col2);
                        String s3 = c.getString(col3);
                        if (teacherID.equals(s1) && teacherPass.equals(s2)) {
                            teachingSubjectsString = s3;
                        }
                        c.moveToNext();
                    }

                    teachingSubjectsString += newTS +"@";

                    ContentValues cv = new ContentValues();
                    cv.put(my_db.TEACHINGSUBJECTS, teachingSubjectsString);

                    sqdb.update(DBHelper.TABLE_TEACHERS, cv, DBHelper.ID+"=? AND "+DBHelper.PASSWORD+"=?", new String[]{teacherID, teacherPass});
                    sqdb.close();
                    showSubjects();

                    Toast.makeText(TeacherSettings.this, "new teaching subject has been added", Toast.LENGTH_SHORT).show();
                }
                else{
                    AlertDialog.Builder adb;
                    adb = new AlertDialog.Builder(TeacherSettings.this);
                    adb.setTitle("Something's wrong");
                    adb.setMessage("There's something wrong in the subject. A subject should have a name and a level, without any special letters (@, $, &, etc.)" + "\n - - to clear  press 'Cancel' - - ");
                    adb.setIcon(R.drawable.iconimportant);
                    adb.setCancelable(false);
                    adb.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            etOtherSubjLvl.setText("");
                        }
                    });
                    AlertDialog adbb = adb.create();
                    adbb.show();
                }
            }
        });

        //setting the spinner again
        spLevels = findViewById(R.id.spLevelsSetts);
        allLevels = new ArrayList<>();
        allLevels.add("Choose level");
        //adding default levels by grades (from 1st to 12th grade)
        for (int i=1; i<=12; i++){
            allLevels.add(i+" grade");
        }
        allLevels.add("Other");
        adapterLevels = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, allLevels);
        spLevels.setAdapter(adapterLevels);
        spLevels.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(allLevels.get(position).equals("Other")){
                    etOtherSubjLvl.setVisibility(View.VISIBLE); //shows etOtherLevel
                }
                else{
                    if (allLevels.get(position).equals("Choose level")){
                        studyLevel = "";
                    }
                    else{ //case of something actually chosen (besides the "other" and "choose level" options)
                        etOtherSubjLvl.setText("");
                        etOtherSubjLvl.setVisibility(View.INVISIBLE);
                        studyLevel = allLevels.get(position);
                    }

                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                studyLevel = "";
            }
        });

        my_db = new DBHelper(this);
        showSubjects();
        sqdb = my_db.getWritableDatabase();
        sqdb.close();
    }

    /**
     * Shows the subjects the teacher teaches in list view
     */
    private void showSubjects() {
        //get the string teachingSubjects from the matching line in DB
        boolean flag = false;

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_TEACHERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            String s3 = c.getString(col3);
            if (teacherID.equals(s1) && teacherPass.equals(s2)) {
                flag = true;
                if(!s3.isEmpty()){ //if there is at least one ts
                    //decipher the string into an arrayList
                    String[] arrAllSubjs = s3.split("@");
                    listArrTeachingSubjects.clear(); //since it saves the list of ts's from before pressing "upd subj"
                    Collections.addAll(listArrTeachingSubjects, arrAllSubjs); //since i can't split a srting straight into the list (& not array) as i need
                    for (int i=0; i<listArrTeachingSubjects.size(); i++){
                        subject = listArrTeachingSubjects.get(i);
                        String[] splittedSubj = subject.split("_");
                        subject = splittedSubj[0]+" - "+splittedSubj[1];
                        listArrTeachingSubjects.set(i, subject);
                    }
                }
                else{
                    listArrTeachingSubjects.add("--No teaching subjects found--");
                }
            }
            c.moveToNext();
        }
        sqdb.close();

        //put the array list into the lv
        adapterSubjs = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1, listArrTeachingSubjects);
        lvTeachingSubjects.setAdapter(adapterSubjs);
    }

    /**
     * Checks if subject is valid
     * a subject is name_level -> name has to be only letters, spaces allowed. A level is the same. they both can be just 1 letter, it's fine
     * @return
     */
    private boolean checkSubject() {
        String strSubjName = etSubjName.getText().toString();

        if (!strSubjName.isEmpty()){
            char[] chars1 = strSubjName.toCharArray();
            for (char c : chars1){
                if (!Character.isLetter(c) && !Character.isSpaceChar(c)){
                    return false;
                }
            }
        }
        else{
            return false;
        }

        if(!studyLevel.isEmpty()){
            char[] chars2 = studyLevel.toCharArray();
            for (char c : chars2){
                if (!Character.isLetter(c) && !Character.isSpaceChar(c) && !Character.isDigit(c)){ //this is letting me avoid "@" or " - " which I split by
                    return false;
                }
            }
        }
        else{
            return false;
        }
        return true;
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

    }
    @Override
    public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
        return false;
    }
}