package com.example.eduprivate;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    /**
 * @author Alexandra Fefler
 * This activity is the login screen where the user can go to registration
 */
    Button btnLogin, btnRegister, btnShowPassword;
    EditText etID, etPassword;

    SQLiteDatabase sqdb;
    DBHelper my_db;

    User user;

    WIFI_Receiver wifiRcvr=new WIFI_Receiver();
    IntentFilter wifiFilter;

    /**
     * Creates and starts activity
     * initializes properties of the class
     * shows all graphics objects
     * @param savedInstanceState helps to start UI
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnLogin = findViewById(R.id.btnLogin);
        btnRegister = findViewById(R.id.btnRegister);
        btnShowPassword = findViewById(R.id.btnShowPassword1);
        etID = findViewById(R.id.etID);
        etPassword = findViewById(R.id.etPassword);

        my_db = new DBHelper(this);
        sqdb = my_db.getWritableDatabase();
        sqdb.close();

        //WIFI broadcast receiver
        wifiFilter=new IntentFilter(WifiManager.WIFI_STATE_CHANGED_ACTION);
        registerReceiver(wifiRcvr, wifiFilter);


        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String strID = etID.getText().toString();
                String strPass = etPassword.getText().toString();
                if (strID.equals("0") && strPass.equals("admin")){
                    Intent goUsersList = new Intent(MainActivity.this, UsersList.class);
                    startActivity(goUsersList);
                }
                if (userExists() != null){
                    user = userExists();
                    //intent according to teacher or student
                    if (userIsTeacher()){
                        Intent goTeacherProfile = new Intent(MainActivity.this, TeacherProfile.class);
                        goTeacherProfile.putExtra("teacherID", user.getID());
                        goTeacherProfile.putExtra("teacherPass", user.getPassword());
                        startActivity(goTeacherProfile);
                    }
                    else{
                        Intent goStudentProfile = new Intent(MainActivity.this, StudentProfile.class);
                        goStudentProfile.putExtra("studentID", user.getID());
                        goStudentProfile.putExtra("studentPass", user.getPassword());
                        startActivity(goStudentProfile);
                    }
                }
                else{
                    AlertDialog.Builder adb;
                    adb = new AlertDialog.Builder(MainActivity.this);
                    adb.setTitle("This user doesn't exist");
                    adb.setMessage("change ID or password and try again" + "\n - - to clear all fields press 'Cancel' - - ");
                    adb.setIcon(R.drawable.iconimportant);
                    adb.setCancelable(false);
                    adb.setPositiveButton("ok", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                        }
                    });
                    adb.setNeutralButton("Cancel", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            etID.setText("");
                            etPassword.setText("");
                        }
                    });
                    AlertDialog adbb = adb.create();
                    adbb.show();
                }
            }
        });

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent goReg = new Intent(MainActivity.this, Registration.class);
                startActivity(goReg);
            }
        });

        btnShowPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(btnShowPassword.getText().toString().equals("Show password")){
                    etPassword.setTransformationMethod(HideReturnsTransformationMethod.getInstance());
                    btnShowPassword.setText("Hide password");
                }
                else{
                    etPassword.setTransformationMethod(PasswordTransformationMethod.getInstance());
                    btnShowPassword.setText("Show password");
                }
            }
        });
    }

    /**
     * Creates menu
     * @param menu
     * @return true
     */
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);

        return true;
    }
    /**
     * When menu option is chosen, does something
     * @param item represents menu item
     * @return super.onOptionsItemSelected(item)
     */
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int itemID = item.getItemId();


        if (itemID == R.id.credits){
            Intent goCred = new Intent(this, Credits.class);
            startActivity(goCred);
        }
        if (itemID == R.id.guide){
            Intent goGuide = new Intent(this, Guide.class);
            startActivity(goGuide);
        }
        if (itemID == R.id.back){
            finish();
        }

        return super.onOptionsItemSelected(item);
    }

    /**
     * Checks if user exists
     * @return true if user exists
     */
    private User userExists() {
        User userr = null;
        Teacher teacherr = null;
        boolean flag=false;
        String strID = etID.getText().toString();
        String strPass = etPassword.getText().toString();

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.NAME);
        int col3 = c.getColumnIndex(DBHelper.PASSWORD);
        int col4 = c.getColumnIndex(DBHelper.PHONE);
        int col5 = c.getColumnIndex(DBHelper.EMAIL);
        int col6 = c.getColumnIndex(DBHelper.ADDRESS);
        int col7 = c.getColumnIndex(DBHelper.PIC);
        int col8 = c.getColumnIndex(DBHelper.ISTEACHER);
        int col9 = c.getColumnIndex(DBHelper.EXTRACOMMENTS);

        int col10 = c.getColumnIndex(DBHelper.PRICE);
        int col11 = c.getColumnIndex(DBHelper.EXPERIENCE);
        int col12 = c.getColumnIndex(DBHelper.TEACHINGSUBJECTS);

        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s3 = c.getString(col3);
            if (strID.equals(s1) && strPass.equals(s3)) {
                flag = true;
                boolean isTeacher = false;
                if (c.getString(col7).equals("true")){
                    isTeacher = true;
                }
                userr = new User(s1,c.getString(col2), s3, c.getString(col4), c.getString(col5), c.getString(col6), c.getString(col7), isTeacher, c.getString(col9));
            }
            if (!c.isAfterLast() && !flag && c.getString(col3).equals("true")){
                boolean isTeacher = false;
                if (c.getString(col8).equals("true")){
                    isTeacher = true;
                }
                int priceInt = 0;
                if (!c.getString(col10).isEmpty()){
                    priceInt = Integer.parseInt(c.getString(col9));
                }
                teacherr = new Teacher(s1,c.getString(col2), s3, c.getString(col4), c.getString(col5), c.getString(col6), c.getString(col7), isTeacher, c.getString(col9), priceInt, c.getString(col11), c.getString(col12));
                userr = (User)teacherr; //המרה למעלה ליוזר
            }
            c.moveToNext();
        }

        sqdb.close();
        Toast.makeText(this, ""+userr, Toast.LENGTH_SHORT).show();
        return userr;
    }

    /**
     * Checks if user is teacher
     * @return true if user is teacher
     */
    private boolean userIsTeacher(){
        boolean flag=false;
        String strID = etID.getText().toString();
        String strPass = etPassword.getText().toString();

        sqdb = my_db.getWritableDatabase();
        Cursor c = sqdb.query(DBHelper.TABLE_ALL_USERS, null, null, null, null, null, null);
        int col1 = c.getColumnIndex(DBHelper.ID);
        int col2 = c.getColumnIndex(DBHelper.PASSWORD);
        int col3 = c.getColumnIndex(DBHelper.ISTEACHER);
        c.moveToFirst();
        while (!c.isAfterLast() && !flag) {
            String s1 = c.getString(col1);
            String s2 = c.getString(col2);
            if (strID.equals(s1) && strPass.equals(s2) && c.getString(col3).equals("true")) {
                flag = true;
            }

            c.moveToNext();
        }
        sqdb.close();
        return flag;
    }


    @Override
    public void onClick(View v) {

    }
}