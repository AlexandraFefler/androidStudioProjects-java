package com.example.eduprivate;

public class Notification {
    /**
     * @author Alexandra Fefler
     * This class represents a notification and it's properties
     */
    private String idReceiver;
    private String passReceiver;
    private String notificationText;
    private String lessonDay;
    private String lessonHour;
    private String lessonSubject;
    private String otherId;
    private String otherPass;
    private String notificationType; //textonly / acceptdeclinebuttons
    private boolean isActive;

    public Notification(String idReceiver, String passReceiver, String notificationText, String lessonDay, String lessonHour, String lessonSubject, String otherId, String otherPass, String notificationType, boolean isActive) {
        this.idReceiver = idReceiver;
        this.passReceiver = passReceiver;
        this.notificationText = notificationText;
        this.lessonDay = lessonDay;
        this.lessonHour = lessonHour;
        this.lessonSubject = lessonSubject;
        this.otherId = otherId;
        this.otherPass = otherPass;
        this.notificationType = notificationType;
        this.isActive = isActive;
    }

    /**
     * Getter for id of receiver
     * @return id of receiver
     */
    public String getIdReceiver() {
        return idReceiver;
    }

    /**
     * Setter for id of receiver
     * @param idReceiver
     */
    public void setIdReceiver(String idReceiver) {
        this.idReceiver = idReceiver;
    }

    /**
     * Getter for password of receiver
     * @return password of receiver
     */
    public String getPassReceiver() {
        return passReceiver;
    }

    /**
     * Setter for password of receiver
     * @param passReceiver
     */
    public void setPassReceiver(String passReceiver) {
        this.passReceiver = passReceiver;
    }

    /**
     * Getter for notification text
     * @return notification text
     */
    public String getNotificationText() {
        return notificationText;
    }

    /**
     * Setter for notification text
     * @param notificationText
     */
    public void setNotificationText(String notificationText) {
        this.notificationText = notificationText;
    }

    /**
     * Getter for lesson day
     * @return lesson day
     */
    public String getLessonDay() {
        return lessonDay;
    }

    /**
     * Setter for lesson day
     * @param lessonDay
     */
    public void setLessonDay(String lessonDay) {
        this.lessonDay = lessonDay;
    }

    /**
     * Getter for lesson hour
     * @return lesson hour
     */
    public String getLessonHour() {
        return lessonHour;
    }

    /**
     * Setter for lesson hour
     * @param lessonHour
     */
    public void setLessonHour(String lessonHour) {
        this.lessonHour = lessonHour;
    }

    /**
     * Getter for lesson subject
     * @return lesson subject
     */
    public String getLessonSubject() {
        return lessonSubject;
    }

    /**
     * Setter for lesson subject
     * @param lessonSubject
     */
    public void setLessonSubject(String lessonSubject) {
        this.lessonSubject = lessonSubject;
    }

    /**
     * Getter for other persons ID
     * @return other persons ID
     */
    public String getOtherId() {
        return otherId;
    }

    /**
     * Setter for other persons ID
     * @param otherId
     */
    public void setOtherId(String otherId) {
        this.otherId = otherId;
    }

    /**
     * Getter for other persons password
     * @return other persons password
     */
    public String getOtherPass() {
        return otherPass;
    }

    /**
     * Setter for other persons password
     * @param otherPass
     */
    public void setOtherPass(String otherPass) {
        this.otherPass = otherPass;
    }

    /**
     * Getter for type of notification
     * @return type of notification
     */
    public String getNotificationType() {
        return notificationType;
    }

    /**
     * Setter for type of notification
     * @param notificationType
     */
    public void setNotificationType(String notificationType) {
        this.notificationType = notificationType;
    }

    public boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * Creates string representation of a notification
     * @return string of a notification
     */
    @Override
    public String toString() {
        return "Notification:" +
                "\nid receiver: "+ idReceiver +
                "\npass receiver: "+ passReceiver +
                "\nnotif text: " + notificationText +
                "\nlesson day: " + lessonDay +
                "\nlesson hour: " + lessonHour +
                "\nlesson subj: " + lessonSubject +
                "\nother id: " + otherId +
                "\nother pass: " + otherPass +
                "\nnotif type: " + notificationType+"\n";
    }
}
